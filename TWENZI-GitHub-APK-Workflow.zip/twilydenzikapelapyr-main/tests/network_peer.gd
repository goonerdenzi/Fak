extends SceneTree
var app: Node
var network: Node
var checks:=0
var failures:=0
var port := 25677
var role: String
var peer_number:=0
var capture_jump:=false
var saw_jump:=false
var server_jumps: Dictionary={}
var server_runs: Dictionary={}
func _initialize() -> void: call_deferred("run")
func check(value: bool,title: String) -> void:
	checks+=1
	if not value: failures+=1
	print(("PASS " if value else "FAIL ")+title)
func wait_seconds(seconds: float) -> void: await create_timer(seconds).timeout
func until(predicate: Callable,seconds: float=30.0) -> bool:
	var deadline:=Time.get_ticks_msec()+int(seconds*1000)
	while Time.get_ticks_msec()<deadline:
		if predicate.call(): return true
		await process_frame
	return false
func _process(_delta: float) -> bool:
	if capture_jump and is_instance_valid(app) and is_instance_valid(app.player):
		if app.player.velocity.y>1.0: saw_jump=true
	if role=="host" and is_instance_valid(network):
		for id in network.actors:
			if id==1: continue
			var actor: CharacterBody3D=network.actors[id]
			if actor.velocity.y>1.0: server_jumps[id]=true
			if Vector2(actor.velocity.x,actor.velocity.z).length()>5.0: server_runs[id]=true
	return false
func run() -> void:
	var args:=OS.get_cmdline_user_args()
	if not OS.get_environment("TWENZI_TEST_PORT").is_empty(): port=int(OS.get_environment("TWENZI_TEST_PORT"))
	role=args[0] if args.size()>0 else "host"
	peer_number=int(args[1]) if args.size()>1 else 0
	network=root.get_node("Session")
	root.get_node("Preferences").selected_character="Denzi" if peer_number==2 else "Twily"
	root.get_node("Preferences").vegetation=0.0
	root.get_node("Profile").inventory=InventoryModel.new()
	root.get_node("Profile").inventory.seed_starter()
	app=load("res://scenes/main/main.tscn").instantiate()
	root.add_child(app)
	app.start_game()
	await wait_seconds(1)
	if role=="host": await host_test()
	elif role=="reject": await reject_test()
	else: await client_test()
	print("RESULT %s %d: %d checks, %d failures"%[role,peer_number,checks,failures])
	network.leave()
	app.show_menu()
	await process_frame
	quit(1 if failures else 0)
func host_test() -> void:
	check(network.host(port,"Host","TESTROOM")==OK,"Host opens real ENet socket")
	print("HOST_READY")
	check(await until(func(): return network.actors.size()==4),"Four real players admitted")
	var names: Array=[]
	for record in network.records.values(): names.append(record.name)
	check(names.has("Client1") and names.has("Client2") and names.has("Client3"),"Unique identities and names registered")
	app.pause_game()
	check(not paused and app.player.input_locked,"Online menu locks only local input")
	await wait_seconds(0.2)
	app.resume()
	Input.action_press("left")
	await wait_seconds(1.2)
	Input.action_release("left")
	check(await until(func():
		for record in network.records.values():
			if record.name=="Client1" and record.outfit.upper=="hoodie_cream": return true
		return false),"Host receives valid client outfit")
	await wait_seconds(3)
	var configs_valid:=true
	for record in network.records.values(): configs_valid=configs_valid and ClothingCatalog.valid(record.outfit)
	check(configs_valid,"Invalid equipment RPC cannot corrupt authoritative outfit")
	check(server_jumps.size()==3,"All three remote jumps simulated on authoritative server")
	check(server_runs.size()==3,"All three remote runs simulated on authoritative server")
	check(network.actors.size()<=4,"Room capacity remains four")
	check(await until(func(): return network.actors.size()==3),"Disconnected player removed by host")
	await wait_seconds(2)
func client_test() -> void:
	check(network.join("127.0.0.1",port,"TESTROOM","Client%d"%peer_number)==OK,"Client starts ENet connection")
	check(await until(func(): return network.joined and network.actors.size()==4),"Client receives four player roster")
	check(network.actors.has(network.multiplayer.get_unique_id()),"Client presence populated")
	var host_start: Vector3=network.actors[1].position
	var start: Vector3=app.player.position
	capture_jump=true
	Input.action_press("forward")
	Input.action_press("run")
	await wait_seconds(0.7)
	Input.action_press("jump")
	await physics_frame
	await physics_frame
	Input.action_release("jump")
	await wait_seconds(0.7)
	Input.action_release("forward")
	Input.action_release("run")
	check(app.player.position.distance_to(start)>2,"Predicted and authoritative movement progresses")
	check(saw_jump,"Jump command executes")
	check(network.actors[1].position.distance_to(host_start)>0.5,"Host movement visible on client")
	if peer_number==1:
		root.get_node("Profile").equip("upper","hoodie_cream")
		app.show_inventory()
		app.choose_inventory(2)
		for b in app.overlay.find_children("*","Button",true,false):
			if b.text=="Use / Equip": b.pressed.emit(); break
		check(await until(func(): return root.get_node("Profile").inventory.health==87,5),"Consumable authorized and replicated")
		await process_frame
		await process_frame
		check(app.detail.text.contains("11 / 20"),"Online inventory panel refreshes after server response")
		app.resume()
		network.inventory_request("drop",4)
		check(await until(func(): return network.drops.size()==1,5),"Dropped item replicated")
		network.pickup_request()
		check(await until(func(): return network.drops.is_empty(),5),"Server validates pickup and removes world item")
		app.travel_to(app.island.regions[10])
		check(await until(func(): return app.player.position.x>1100,8),"Region travel authorized by host")
	if peer_number==2:
		var bad:=ClothingCatalog.defaults("Denzi")
		bad.upper="untrusted_model_path"
		network.request_outfit(bad)
	check(await until(func():
		for id in network.records:
			if network.records[id].name=="Client1": return network.actors[id].visual.equipment.upper=="hoodie_cream"
		return false,10),"Client sees another player's equipped 3D clothing")
	if peer_number==3:
		await wait_seconds(7)
		network.leave()
		check(not network.active,"Client disconnect closes session")
	else:
		check(await until(func(): return network.actors.size()==3,20),"Remote disconnect removes avatar")
func reject_test() -> void:
	var code: String="WRONG" if peer_number==0 else "TESTROOM"
	network.join("127.0.0.1",port,code,"Rejected")
	await wait_seconds(4)
	check(not network.joined,"Wrong-code / over-capacity client is not admitted")
