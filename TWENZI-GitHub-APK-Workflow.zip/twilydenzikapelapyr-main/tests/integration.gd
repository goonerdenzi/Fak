extends SceneTree
var app: Node
var failures := 0
var checks := 0
func _initialize() -> void:
	call_deferred("run")
func check(value: bool,message: String) -> void:
	checks += 1
	if not value: failures += 1
	print(("PASS " if value else "FAIL ")+message)
func frames(count: int) -> void:
	for i in count: await physics_frame
func run() -> void:
	root.get_node("Preferences").reset_controls()
	app = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(app)
	await frames(3)
	check(is_instance_valid(app.menu),"Main menu loads")
	for b in app.menu.find_children("*","Button",true,false):
		if b.text.begins_with("Explore"): b.pressed.emit()
	await frames(120)
	var p: CharacterBody3D = app.player
	for b in app.hud.find_children("*","Button",true,false):
		check(app.ui.get_global_rect().encloses(b.get_global_rect()),"HUD control visible: "+b.text)
	check(p.is_on_floor(),"Player settles on terrain collision")
	for dimensions in [Vector2i(1600,900),Vector2i(2000,900)]:
		root.size=dimensions
		await frames(3)
		var contained := true
		for b in app.hud.find_children("*","Button",true,false):
			contained = contained and app.ui.get_global_rect().encloses(b.get_global_rect())
		check(contained,"HUD fits landscape viewport "+str(dimensions))
	root.size=Vector2i(1440,900)
	await frames(3)
	check(app.island.chunks.size()>=25,"Terrain chunks stream around player")
	var start := p.position
	Input.action_press("forward")
	await frames(60)
	Input.action_release("forward")
	check(p.position.distance_to(start)>2,"Desktop forward movement")
	await frames(25)
	var y := p.position.y
	Input.action_press("jump")
	await frames(1)
	Input.action_release("jump")
	await frames(12)
	check(p.position.y>y+0.3,"Jump rises off ground")
	await frames(90)
	check(p.is_on_floor(),"Jump lands on terrain")
	start = p.position
	p.rig.switch_view()
	check(p.rig.first_person and not p.visual.visible,"First-person hides body")
	check(p.position==start,"Camera switch preserves position")
	p.rig.switch_view()
	check(not p.rig.first_person and p.visual.visible,"Third-person restores body")
	var yaw: float = p.rig.yaw
	p.rig.look(Vector2(100,20))
	check(p.rig.yaw!=yaw,"Camera rotation changes yaw")
	# Real screen touch/drag events exercise joystick ID ownership and camera routing.
	var t := InputEventScreenTouch.new()
	t.index=2; t.pressed=true; t.position=Vector2(120,700)
	app.touch._input(t)
	var drag := InputEventScreenDrag.new()
	drag.index=2; drag.position=Vector2(120,640)
	app.touch._input(drag)
	check(p.touch_move.y < -0.5,"Touch joystick supplies movement")
	var jump_button: Button
	for b in app.hud.find_children("*","Button",true,false):
		if b.text=="Jump": jump_button=b
	var second := InputEventScreenTouch.new()
	second.index=4
	second.pressed=true
	second.position=jump_button.get_global_rect().get_center()
	app.touch._input(second)
	check(p.jump_queued and p.touch_move.y < -0.5,"Second finger jumps while joystick remains held")
	start=p.position
	await frames(30)
	check(p.position.distance_to(start)>0.5,"Touch input moves character")
	t.pressed=false
	app.touch._input(t)
	check(p.touch_move==Vector2.ZERO,"Touch release stops joystick")
	t.index=3; t.pressed=true; t.position=Vector2(1000,300)
	app.touch._input(t)
	drag.index=3; drag.relative=Vector2(40,0)
	yaw=p.rig.yaw
	app.touch._input(drag)
	check(p.rig.yaw!=yaw,"Right touch area rotates camera")
	t.pressed=false
	app.touch._input(t)
	# Camera spring arm retracts in front of an actual wall.
	p.rig.yaw=0
	p.rig.pitch=0
	var wall := StaticBody3D.new()
	var collision := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size=Vector3(4,4,0.4)
	collision.shape=shape
	wall.add_child(collision)
	root.add_child(wall)
	wall.position=p.position+Vector3(0,1.5,2.5)
	await frames(20)
	check(p.rig.arm.get_hit_length()<p.rig.distance-1.0,"Camera retracts against solid wall")
	wall.queue_free()
	# Exercise every movement direction and the actual run toggle callback.
	var platform := StaticBody3D.new()
	var floor_collision := CollisionShape3D.new()
	var floor_shape := BoxShape3D.new()
	floor_shape.size=Vector3(24,1,24)
	floor_collision.shape=floor_shape
	platform.add_child(floor_collision)
	root.add_child(platform)
	platform.position=p.position+Vector3.UP*5
	var test_origin := platform.position+Vector3.UP*1.5
	p.position=test_origin
	p.velocity=Vector3.ZERO
	await frames(40)
	for action in ["back","left","right"]:
		p.position=test_origin
		p.velocity=Vector3.ZERO
		await frames(25)
		start=p.position
		Input.action_press(action)
		await frames(25)
		Input.action_release(action)
		check(p.position.distance_to(start)>0.5,"Desktop movement: "+action)
	var run_button: Button
	for b in app.hud.find_children("*","Button",true,false):
		if b.text=="Run": run_button=b
	run_button.button_pressed=true
	Input.action_press("forward")
	await frames(20)
	check(p.touch_run and Vector2(p.velocity.x,p.velocity.z).length()>5.0,"Run button increases movement speed")
	Input.action_release("forward")
	run_button.button_pressed=false
	platform.queue_free()
	app.pause_game()
	start=p.position
	await frames(10)
	check(paused and p.position==start,"Pause freezes simulation")
	app.resume()
	check(not paused,"Resume restores simulation")
	app.show_map()
	check(paused and is_instance_valid(app.overlay),"Field guide opens")
	app.travel_to(app.island.regions[0])
	await frames(60)
	p.position=app.island.markers[0].position+Vector3(2,1,2)
	await frames(30)
	app.interact()
	check(app.visited.size()==1,"Landmark interaction records discovery")
	for region in app.island.regions:
		app.travel_to(region)
		await frames(75)
		check(p.is_on_floor(),"Explorable terrain at "+str(region.name))
	app.pause_game()
	app.show_settings()
	check(is_instance_valid(app.overlay),"Settings opens")
	app.show_menu()
	await frames(2)
	check(not app.playing and not paused and is_instance_valid(app.menu),"Return to menu clears session")
	root.get_node("Preferences").selected_character="Denzi"
	app.start_game()
	await frames(60)
	check(app.player.character_name=="Denzi","Separate Denzi scene playable")
	app.show_menu()
	await frames(2)
	print("RESULT %d checks, %d failures" % [checks,failures])
	quit(1 if failures else 0)
