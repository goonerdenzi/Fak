extends SceneTree
var checks:=0
var failures:=0
func _initialize() -> void: call_deferred("run")
func check(value: bool,title: String) -> void:
	checks+=1
	if not value: failures+=1
	print(("PASS " if value else "FAIL ")+title)
func run() -> void:
	var bag:=InventoryModel.new()
	check(bag.add("wood",65)==0,"Add and distribute stacks")
	check(bag.slots[0].quantity==50 and bag.slots[1].quantity==15,"Stack limit respected")
	check(bag.split(0) and bag.slots[0].quantity==25,"Split stack into empty slot")
	check(bag.move(1,0) and bag.slots[0].quantity==40,"Merge matching stacks")
	check(bag.drop(0,4).quantity==4 and bag.slots[0].quantity==36,"Drop exact quantity")
	check(bag.drop(0,100).is_empty(),"Reject oversized drop")
	check(bag.add("unknown",3)==3,"Reject unknown item")
	bag.add("berries",3)
	bag.health=40
	var berry_index: int=-1
	for i in bag.CAPACITY:
		if bag.slots[i].get("id")=="berries": berry_index=i
	check(bag.use(berry_index).heal==12 and bag.health==52,"Consumable changes real health")
	var snapshot:=bag.snapshot()
	var restored:=InventoryModel.new()
	check(restored.restore(snapshot) and restored.snapshot()==snapshot,"Inventory round trip")
	snapshot.slots[0].quantity=999
	check(not restored.restore(snapshot),"Reject invalid saved stack")
	check(not bag.move(-1,4) and not bag.split(99),"Reject invalid indices")
	var tools:=InventoryModel.new()
	tools.add("axe",1)
	tools.use(0)
	tools.drop(0)
	check(tools.active_tool.is_empty(),"Dropping last tool clears equipment")
	var full:=InventoryModel.new()
	full.add("stone",1200)
	check(full.add("berries",1)==1 and not full.split(0),"Full inventory rejects overflow and split without item loss")
	var outfit:=ClothingCatalog.defaults("Twily")
	check(ClothingCatalog.valid(outfit),"Default outfit valid")
	outfit.upper="hair_bob"
	check(not ClothingCatalog.valid(outfit),"Reject item in incorrect clothing slot")
	outfit.upper="bad_id"
	check(not ClothingCatalog.valid(outfit),"Reject unknown equipment identifier")
	var visual=load("res://scripts/player/modular_visual.gd").new()
	root.add_child(visual)
	check(visual.skeleton.get_bone_count()==18,"Articulated 18 bone skeleton")
	outfit=ClothingCatalog.defaults("Twily")
	var shoe_instance: int=visual.slots.shoes.get_child(0).get_instance_id()
	outfit.upper="hoodie_cream"
	check(visual.apply_outfit(outfit) and visual.slots.upper.get_child_count()>0,"Clothing produces actual 3D geometry")
	check(visual.slots.shoes.get_child(0).get_instance_id()==shoe_instance,"Changing upper slot preserves other equipment nodes")
	outfit.backpack=""
	check(visual.apply_outfit(outfit) and visual.slots.backpack.get_child_count()==0,"Unequip removes only slot geometry")
	visual.animate(0.1,7.0,true,0.0)
	check(visual.animation_state=="run","Running pose active")
	visual.trigger_action()
	visual.animate(0.1,0,true,0)
	check(visual.animation_state=="interact","Interaction animation active")
	var profile:=root.get_node("Profile")
	profile.path="user://part2-test-profile.json"
	check(profile.equip("upper","hoodie_cream"),"Equip profile slot")
	check(profile.save_outfit("Test") and profile.equip("upper","jacket_green") and profile.load_outfit("Test"),"Save and switch outfit")
	check(profile.save_profile() and profile.load_profile(),"Profile disk persistence")
	visual.queue_free()
	print("RESULT %d checks, %d failures"%[checks,failures])
	quit(1 if failures else 0)
