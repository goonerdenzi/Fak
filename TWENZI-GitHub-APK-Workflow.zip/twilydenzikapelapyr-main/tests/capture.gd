extends SceneTree
var app: Node
func _initialize() -> void:
	call_deferred("run")
func settle(count: int=6) -> void:
	for i in count:
		await process_frame
		while not app.island.queue.is_empty(): app.island.build_chunk(app.island.queue.pop_front())
func shot(name: String) -> void:
	await RenderingServer.frame_post_draw
	var path := OS.get_environment("TWENZI_CAPTURES")
	if path.is_empty(): path="/workspace/work/captures"
	DirAccess.make_dir_recursive_absolute(path)
	root.get_texture().get_image().save_png(path+"/"+name+".png")
	print("CAPTURE "+name)
func run() -> void:
	root.size=Vector2i(1440,900)
	app=load("res://scenes/main/main.tscn").instantiate()
	root.add_child(app)
	if "--lake-only" in OS.get_cmdline_user_args():
		app.start_game()
		app.travel_to(app.island.regions[4])
		for i in 60: await physics_frame
		app.player.rig.yaw=-1.4
		app.player.rig.pitch=-0.25
		app.player.rig.switch_view()
		await settle()
		await shot("04-lake-first-person")
		app.pause_game()
		await settle(3)
		await shot("05-pause")
		quit()
		return
	await settle()
	await shot("01-menu")
	app.start_game()
	for i in 60: await physics_frame
	await settle()
	await shot("02-coast")
	app.travel_to(app.island.regions[3])
	for i in 60: await physics_frame
	app.player.rig.pitch=-0.25
	app.player.rig.yaw=2.3
	await settle()
	await shot("03-highlands")
	app.travel_to(app.island.regions[4])
	for i in 60: await physics_frame
	app.player.rig.yaw=-1.4
	app.player.rig.switch_view()
	await settle()
	await shot("04-lake-first-person")
	app.pause_game()
	await settle(3)
	await shot("05-pause")
	quit()
