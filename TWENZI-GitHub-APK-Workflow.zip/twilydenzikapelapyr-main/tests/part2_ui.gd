extends SceneTree
var app: Node
var checks:=0
var failures:=0
func _initialize() -> void: call_deferred("run")
func frames(n: int=3) -> void:
	for i in n: await process_frame
func check(value: bool,title: String) -> void:
	checks+=1
	if not value: failures+=1
	print(("PASS " if value else "FAIL ")+title)
func press(text: String) -> bool:
	for b in app.overlay.find_children("*","Button",true,false):
		if b.text==text: b.pressed.emit(); return true
	return false
func panels_fit() -> bool:
	for b in app.overlay.find_children("*","Button",true,false):
		if not b.is_visible_in_tree(): continue
		if not app.ui.get_global_rect().encloses(b.get_global_rect()): return false
	return true
func run() -> void:
	root.size=Vector2i(1440,900)
	root.get_node("Preferences").selected_character="Twily"
	root.get_node("Preferences").reset_controls()
	app=load("res://scenes/main/main.tscn").instantiate()
	root.add_child(app)
	app.start_game()
	root.get_node("Profile").inventory.restore({"slots":[{"id":"axe","quantity":1},{"id":"pick","quantity":1},{"id":"berries","quantity":5},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}],"health":50,"selected":0,"tool":""})
	await frames()
	app.select_hotbar(0)
	check(app.player.visual.held_tool=="axe" and app.player.visual.tool_group.get_child_count()>0,"Hotbar equips visible 3D tool")
	app.select_hotbar(2)
	check(app.player.visual.held_tool.is_empty(),"Food selection clears held tool")
	app.show_inventory()
	app.choose_inventory(2)
	await frames()
	check(panels_fit(),"Inventory panel fits viewport")
	check(press("Use / Equip"),"Inventory Use button connected")
	await frames()
	check(root.get_node("Profile").inventory.health==62,"Inventory button consumes and heals")
	app.choose_inventory(0)
	press("Move · then choose destination")
	app.choose_inventory(15)
	check(root.get_node("Profile").inventory.slots[15].id=="axe","Inventory UI moves selected stack")
	app.choose_inventory(2)
	press("Split stack")
	check(root.get_node("Profile").inventory.slots[2].quantity==2,"Inventory UI splits stack")
	press("Drop one")
	check(app.local_drops.size()==1,"Drop UI creates actual world pickup")
	app.resume()
	app.player.position=app.local_drops[0].position
	app.interact()
	check(app.local_drops.is_empty(),"World pickup returns dropped item")
	app.show_outfit()
	await frames()
	check(panels_fit(),"Outfit panel fits viewport")
	check(is_instance_valid(app.preview_model.model.skeleton),"Outfit preview renders articulated 3D model")
	press("Oatmeal hoodie")
	await frames()
	check(app.player.visual.equipment.upper=="hoodie_cream","Outfit UI changes actual player mesh")
	app.wardrobe_slot="backpack"
	app.show_outfit()
	press("Unequip backpack")
	check(app.player.visual.slots.backpack.get_child_count()==0,"Outfit UI unequips independent slot")
	app.show_controls()
	await frames()
	check(panels_fit(),"Control customization fits viewport")
	root.get_node("Preferences").run_hold=true
	press("Apply & close")
	await frames()
	var run: Button
	for b in app.hud.find_children("*","Button",true,false):
		if b.text=="Run": run=b
	var touch:=InputEventScreenTouch.new()
	touch.index=8; touch.pressed=true; touch.position=run.get_global_rect().get_center()
	app.touch._input(touch)
	check(app.player.touch_run,"Hold-run touch starts running")
	touch.pressed=false
	app.touch._input(touch)
	check(not app.player.touch_run,"Hold-run release stops running")
	app.show_map()
	await frames()
	check(is_instance_valid(app.overlay) and app.island.regions.size()==14,"Expanded field guide contains 14 regions")
	app.resume()
	app.island.set_sunset(true)
	check(app.island.sunset and is_equal_approx(app.island.sun.rotation_degrees.x,-16.0),"Sunset changes actual lighting")
	app.show_menu()
	await frames()
	print("RESULT %d checks, %d failures"%[checks,failures])
	quit(1 if failures else 0)
