extends SceneTree
var app: Node
func _initialize() -> void: call_deferred("run")
func settle() -> void:
	for i in 5:
		await process_frame
		while not app.island.queue.is_empty(): app.island.build_chunk(app.island.queue.pop_front())
func shot(title: String) -> void:
	await RenderingServer.frame_post_draw
	var dir:=OS.get_environment("TWENZI_CAPTURES")
	if dir.is_empty(): dir="/workspace/work/part2-captures"
	DirAccess.make_dir_recursive_absolute(dir)
	root.get_texture().get_image().save_png(dir+"/"+title+".png")
	print("CAPTURE "+title)
func run() -> void:
	root.size=Vector2i(1440,900)
	root.get_node("Preferences").selected_character="Twily"
	root.get_node("Preferences").view_distance=2
	root.get_node("Preferences").vegetation=0.55
	app=load("res://scenes/main/main.tscn").instantiate()
	root.add_child(app)
	app.start_game()
	for i in 65: await physics_frame
	await settle()
	await shot("01-playable-hud")
	app.show_outfit()
	await settle()
	await shot("02-wardrobe")
	app.show_inventory()
	app.choose_inventory(2)
	await settle()
	await shot("03-inventory")
	app.resume()
	app.player.rig.yaw=PI
	app.player.rig.distance=3.2
	await settle()
	await shot("04-twily-front")
	app.island.set_sunset(true)
	await settle()
	await shot("05-sunset")
	app.show_menu()
	root.get_node("Preferences").selected_character="Denzi"
	app.start_game()
	app.show_outfit()
	await settle()
	await shot("06-denzi")
	app.resume()
	app.island.set_sunset(false)
	app.travel_to(app.island.regions[13])
	await settle()
	var landmark: Vector3=app.island.markers[13].position
	app.preview.position=landmark+Vector3(28,20,32)
	app.preview.look_at(landmark+Vector3.UP*6)
	app.preview.make_current()
	await settle()
	await shot("07-eastern-beacon")
	quit()
