"""Launch one ENet host, three clients and two rejection probes in real processes."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
import time

parser = argparse.ArgumentParser()
parser.add_argument('--logs', default='work/network-results')
parser.add_argument('--port', type=int, default=25677)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
logs = Path(args.logs).resolve()
logs.mkdir(parents=True, exist_ok=True)
processes = []
failed = False
with tempfile.TemporaryDirectory(prefix='twenzi-network-') as temp:
    def start(role, number):
        name = f'{role}-{number}'
        env = os.environ.copy()
        env.pop('TWENZI_PROFILE', None)
        env.update(XDG_DATA_HOME=f'{temp}/{name}/data', XDG_CONFIG_HOME=f'{temp}/{name}/config', XDG_CACHE_HOME=f'{temp}/{name}/cache', TWENZI_TEST_PORT=str(args.port))
        stream = open(logs/(name+'.log'), 'w')
        process = subprocess.Popen(['godot','--headless','--path',str(root),'--script','tests/network_peer.gd','--',role,str(number)],env=env,stdout=stream,stderr=subprocess.STDOUT)
        processes.append((name,process,stream))
        return process
    try:
        host = start('host',0)
        deadline = time.monotonic()+50
        while time.monotonic()<deadline:
            if 'HOST_READY' in (logs/'host-0.log').read_text(): break
            if host.poll() is not None: raise RuntimeError('Host failed; inspect log')
            time.sleep(.2)
        else: raise TimeoutError('Host did not become ready')
        wrong = start('reject',0)
        wrong.wait(timeout=30)
        for number in range(1,4): start('client',number)
        deadline = time.monotonic()+50
        while time.monotonic()<deadline:
            if 'PASS Four real players admitted' in (logs/'host-0.log').read_text(): break
            time.sleep(.2)
        else: raise TimeoutError('Four clients did not join')
        start('reject',1)
        for name,process,stream in processes:
            process.wait(timeout=65)
            stream.close()
            output = (logs/(name+'.log')).read_text()
            clean = process.returncode==0 and 'RESULT ' in output and 'SCRIPT ERROR' not in output and 'ERROR:' not in output
            failed = failed or not clean
            print(name,'OK' if clean else 'FAILED',flush=True)
            for line in output.splitlines():
                if line.startswith(('FAIL ','RESULT ','SCRIPT ERROR','ERROR:')): print(line,flush=True)
    finally:
        for _,process,stream in processes:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
            if not stream.closed: stream.close()
raise SystemExit(1 if failed else 0)
