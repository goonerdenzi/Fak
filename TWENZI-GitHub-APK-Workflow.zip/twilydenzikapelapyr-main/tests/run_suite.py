"""Run offline tests with isolated user data; require both clean logs and exit success."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--logs', default='work/test-results')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
logs = Path(args.logs).resolve()
logs.mkdir(parents=True, exist_ok=True)
failed = False
for script in ['part2_models.gd', 'part2_ui.gd', 'integration.gd']:
    with tempfile.TemporaryDirectory(prefix='twenzi-test-') as temp:
        env = os.environ.copy()
        env.update(XDG_DATA_HOME=temp+'/data', XDG_CONFIG_HOME=temp+'/config', XDG_CACHE_HOME=temp+'/cache')
        env.pop('TWENZI_PROFILE', None)
        result = subprocess.run(['godot', '--headless', '--path', str(root), '--script', 'tests/'+script], env=env, capture_output=True, text=True, timeout=180)
        output = result.stdout + result.stderr
        (logs/(script+'.log')).write_text(output)
        clean = result.returncode == 0 and 'RESULT ' in output and 'SCRIPT ERROR' not in output and 'ERROR:' not in output
        failed = failed or not clean
        print(script, 'OK' if clean else 'FAILED', flush=True)
        for line in output.splitlines():
            if line.startswith(('FAIL ', 'RESULT ', 'SCRIPT ERROR', 'ERROR:')):
                print(line, flush=True)
raise SystemExit(1 if failed else 0)
