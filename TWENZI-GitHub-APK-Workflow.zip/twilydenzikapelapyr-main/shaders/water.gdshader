shader_type spatial;
render_mode cull_disabled;
uniform sampler2D height_map : filter_linear, repeat_disable;
uniform vec4 map_bounds=vec4(-1200.0,-1400.0,3800.0,2800.0);
uniform bool use_depth = true;
varying vec3 world;
void vertex(){world=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;VERTEX.y+=sin(world.x*0.13+TIME*0.8)*0.08+cos(world.z*0.17+TIME*0.6)*0.06;}
void fragment(){
 float bed=texture(height_map,(world.xz-map_bounds.xy)/map_bounds.zw).r;
 float depth=use_depth?max(0.0,world.y-bed):5.0;
 vec3 shallow=vec3(0.035,0.57,0.51), deep=vec3(0.014,0.13,0.32);
 ALBEDO=mix(shallow,deep,smoothstep(0.2,19.0,depth));
 float foam=(1.0-smoothstep(0.2,1.5,depth))*(0.55+0.45*sin(depth*10.0-TIME*2.2));
 ALBEDO=mix(ALBEDO,vec3(0.84,0.97,0.91),foam);
 float fade=1.0-smoothstep(50.0,500.0,length(VERTEX));
 NORMAL_MAP=vec3(0.5+sin(world.x*0.7+world.z*0.3+TIME)*0.045*fade,0.5+cos(world.z*0.8-world.x*0.2+TIME)*0.045*fade,1.0);
 METALLIC=0.15; ROUGHNESS=0.31+foam*0.4;
}
