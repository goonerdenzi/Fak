shader_type spatial;
render_mode cull_disabled;
uniform vec4 tint : source_color = vec4(0.19,0.29,0.10,1.0);
void vertex(){vec3 w=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;VERTEX.x+=sin(TIME*1.2+w.x*0.3+w.z*0.2)*0.12*UV.y;}
void fragment(){float vein=abs(UV.x-0.5)*2.0;ALBEDO=tint.rgb*(0.65+0.35*vein)*(0.9+0.1*sin(UV.y*75.0));ROUGHNESS=0.8;}
