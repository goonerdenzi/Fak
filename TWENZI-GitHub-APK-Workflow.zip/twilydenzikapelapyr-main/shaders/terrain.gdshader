shader_type spatial;
render_mode cull_back;
uniform float detail = 1.0;
varying vec3 world;
varying vec3 norm;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
float noise(vec2 p){vec2 i=floor(p);vec2 f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.0),f.x),f.y);}
void vertex(){world=(MODEL_MATRIX*vec4(VERTEX,1.0)).xyz;norm=normalize(MODEL_NORMAL_MATRIX*NORMAL);}
void fragment(){
 float n=noise(world.xz*0.15)*0.55+noise(world.xz*1.7)*0.3+noise(world.xz*10.0)*0.15;
 vec3 sand=mix(vec3(0.52,0.42,0.25),vec3(0.85,0.75,0.49),n);
 vec3 grass=mix(vec3(0.10,0.20,0.055),vec3(0.35,0.43,0.12),n);
 vec3 stone=mix(vec3(0.17,0.19,0.18),vec3(0.39,0.38,0.33),n);
 float beach=smoothstep(2.0,8.5,world.y+noise(world.xz*0.03)*3.0);
 float rock=max(1.0-smoothstep(0.55,0.88,norm.y),smoothstep(100.0,170.0,world.y));
 ALBEDO=mix(mix(sand,grass,beach),stone,rock);
 ALBEDO*=mix(0.65,1.0,smoothstep(-0.3,2.0,world.y));
 ROUGHNESS=0.93;
 NORMAL_MAP=vec3(0.5+(n-0.5)*0.14*detail,0.5+(noise(world.xz*6.0)-0.5)*0.14*detail,1.0);
}
