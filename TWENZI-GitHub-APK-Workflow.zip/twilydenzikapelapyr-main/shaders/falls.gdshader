shader_type spatial;
render_mode cull_disabled;
void vertex(){VERTEX.z+=sin(VERTEX.x*6.0+TIME*3.0)*0.06;}
void fragment(){float streams=sin(UV.x*120.0+sin(UV.y*40.0-TIME*4.0));ALBEDO=mix(vec3(0.12,0.55,0.61),vec3(0.80,0.94,0.95),streams*0.3+0.5);ROUGHNESS=0.36;}
