shader_type sky;
uniform float sunset = 0.0;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p), f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+1.0),f.x),f.y);}
float fbm(vec2 p){return n(p)*0.53+n(p*2.03)*0.27+n(p*4.1)*0.13+n(p*8.3)*0.07;}
void sky(){
 float y=max(EYEDIR.y,0.0);
 vec3 horizon=mix(vec3(0.54,0.80,0.94),vec3(0.96,0.54,0.29),sunset);
 vec3 zenith=mix(vec3(0.06,0.34,0.75),vec3(0.16,0.19,0.39),sunset);
 COLOR=mix(horizon,zenith,sqrt(y));
 vec2 uv=EYEDIR.xz/max(0.14,EYEDIR.y)*1.4;
 float clouds=smoothstep(0.52,0.70,fbm(uv));
 float edges=fbm(uv+0.13);
 vec3 cloud=mix(vec3(0.64,0.75,0.86),vec3(1.0,0.97,0.87),edges);
 cloud=mix(cloud,vec3(1.0,0.64,0.40),sunset*0.6);
 // Hide the clamped projection near the horizon to avoid vertical cloud streaks.
 COLOR=mix(COLOR,cloud,clouds*smoothstep(0.14,0.28,y));
}
