extends Node
var island: Node3D
var player: CharacterBody3D
var ui: Control
var layer: CanvasLayer
var menu: Control
var hud: Control
var overlay: Control
var touch: Control
var info: Label
var prompt: Label
var toast: Label
var preview: Camera3D
var visited: Dictionary = {}
var playing := false
var nearest: Node3D
var game_theme: Theme

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	setup_input()
	setup_theme()
	island = load("res://scenes/world/island.tscn").instantiate()
	island.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(island)
	preview = Camera3D.new()
	island.add_child(preview)
	preview.position = Vector3(-180,36,800)
	preview.look_at(Vector3(-90,8,650))
	preview.far = 2500
	island.focus = preview
	island.ensure_ground(preview.position)
	layer = CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.theme = game_theme
	layer.add_child(ui)
	show_menu()

func setup_input() -> void:
	var actions := {"forward":KEY_W,"back":KEY_S,"left":KEY_A,"right":KEY_D,"jump":KEY_SPACE,"run":KEY_SHIFT,"camera":KEY_V,"interact":KEY_E,"pause":KEY_ESCAPE,"map":KEY_M}
	for action in actions:
		InputMap.add_action(action)
		var event := InputEventKey.new()
		event.physical_keycode = actions[action]
		InputMap.action_add_event(action,event)

func setup_theme() -> void:
	game_theme = Theme.new()
	game_theme.default_font_size = 20
	game_theme.set_color("font_shadow_color","Label",Color(0.02,0.04,0.04,0.85))
	game_theme.set_constant("shadow_offset_x","Label",1)
	game_theme.set_constant("shadow_offset_y","Label",2)
	game_theme.set_color("font_color","Label",Color("e7e8d8"))
	for state in ["normal","hover","pressed","focus","disabled"]:
		var style := StyleBoxFlat.new()
		style.bg_color = Color("253c3a") if state == "hover" else Color(0.04,0.10,0.11,0.88)
		style.border_color = Color("8b9d89") if state=="focus" else Color(0.6,0.7,0.6,0.3)
		style.set_border_width_all(1)
		style.set_corner_radius_all(4)
		style.content_margin_left = 22
		style.content_margin_right = 22
		style.content_margin_top = 13
		style.content_margin_bottom = 13
		game_theme.set_stylebox(state,"Button",style)
	game_theme.set_color("font_color","Button",Color("ebe5d2"))

func label(parent: Node,text: String,font_size: int=20) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size",font_size)
	parent.add_child(l)
	return l
func button(parent: Node,text: String,callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0,52)
	b.pressed.connect(callback)
	parent.add_child(b)
	return b
func backdrop(parent: Node,alpha: float) -> ColorRect:
	var rect := ColorRect.new()
	rect.color = Color(0.025,0.055,0.06,alpha)
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(rect)
	return rect
func column(parent: Node,pos: Vector2,width: float) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.position = pos
	box.custom_minimum_size.x = width
	box.add_theme_constant_override("separation",12)
	parent.add_child(box)
	return box
func clear_overlay() -> void:
	if is_instance_valid(overlay):
		overlay.queue_free()
		overlay = null

func show_menu() -> void:
	get_tree().paused = false
	playing = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	clear_overlay()
	if is_instance_valid(hud): hud.queue_free()
	if is_instance_valid(player): player.queue_free()
	island.focus = preview
	preview.make_current()
	menu = Control.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(menu)
	backdrop(menu,0.28)
	var box := column(menu,Vector2(90,105),420)
	label(box,"T W O   S O U L S .   O N E   H O R I Z O N .",16)
	label(box,"TWENZI",84)
	label(box,"Our Little World",30)
	label(box,"\nAn island to find your own way.\n",20)
	button(box,"Explore  /  Free Mode",start_game)
	button(box,"Settings",show_settings)
	var story := button(box,"Story Mode  ·  Coming soon",func(): pass)
	story.disabled = true
	if not OS.has_feature("Android"): button(box,"Exit",func(): get_tree().quit())
	var footer := label(menu,"PART 01     /     THE ISLAND FOUNDATION",16)
	footer.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	footer.position = Vector2(90,ui.size.y-65)

func start_game() -> void:
	menu.queue_free()
	clear_overlay()
	playing = true
	var path := "res://scenes/characters/%s.tscn" % Preferences.selected_character.to_lower()
	player = load(path).instantiate()
	player.process_mode = Node.PROCESS_MODE_PAUSABLE
	var spawn := Vector3(-120,0,750)
	spawn.y = IslandShape.height(spawn.x,spawn.z)+1.0
	island.ensure_ground(spawn)
	player.position = spawn
	add_child(player)
	island.focus = player
	player.interaction_requested.connect(interact)
	make_hud()
	if not OS.has_feature("Android"): Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func make_hud() -> void:
	hud = Control.new()
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(hud)
	touch = load("res://scripts/ui/touch_controls.gd").new()
	touch.player = player
	hud.add_child(touch)
	info = label(hud,"",22)
	info.position = Vector2(36,28)
	prompt = label(hud,"",18)
	prompt.position = Vector2(36,90)
	toast = label(hud,"Find the coast camp. Explore at your own pace.",20)
	toast.position = Vector2(36,135)
	var actions := HBoxContainer.new()
	hud.add_child(actions)
	actions.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	actions.offset_left = -380
	actions.offset_right = -24
	actions.offset_top = 24
	actions.offset_bottom = 80
	button(actions,"Map",show_map)
	button(actions,"View",func(): player.rig.switch_view())
	button(actions,"Pause",pause_game)
	var controls := HBoxContainer.new()
	hud.add_child(controls)
	controls.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	controls.offset_left = -530
	controls.offset_right = -24
	controls.offset_top = -95
	controls.offset_bottom = -35
	controls.add_theme_constant_override("separation",12)
	var run := button(controls,"Run",func(): pass)
	run.toggle_mode = true
	run.toggled.connect(func(on: bool): player.touch_run = on)
	button(controls,"Jump",func(): player.jump_queued = true)
	button(controls,"Interact",interact)
	var help := label(hud,"WASD  Move   ·   Shift  Run   ·   Space  Jump   ·   V  View   ·   E  Interact   ·   M  Map",15)
	help.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	help.position = Vector2(30,ui.size.y-28)
	if OS.has_feature("Android"): help.hide()

func _process(_delta: float) -> void:
	if not playing or not is_instance_valid(player): return
	info.text = "%s  /  %s\n%s" % [player.character_name,"First person" if player.rig.first_person else "Third person",region_name()]
	nearest = null
	for marker in island.markers:
		if player.global_position.distance_to(marker.global_position)<9:
			nearest = marker
			break
	prompt.text = "E / Interact  ·  "+str(nearest.get_meta("title")) if nearest else "Explore the island  ·  %d / %d places discovered" % [visited.size(),island.regions.size()]

func region_name() -> String:
	var best := INF
	var title := "Open sea"
	for marker in island.markers:
		var d := player.position.distance_to(marker.position)
		if d<best:
			best = d
			title = marker.get_meta("title")
	return title
func interact() -> void:
	if nearest:
		visited[nearest.get_meta("title")] = true
		toast.text = "Discovered: %s\n%s" % [nearest.get_meta("title"),nearest.get_meta("description")]
	else: toast.text = "Move closer to a campsite, ruin or landmark to discover it."
func pause_game() -> void:
	get_tree().paused = true
	touch.reset()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(overlay)
	backdrop(overlay,0.78)
	var box := column(overlay,Vector2(90,180),420)
	label(box,"A MOMENT OF STILLNESS",18)
	label(box,"Paused",52)
	button(box,"Resume",resume)
	button(box,"Settings",show_settings)
	button(box,"Return to Main Menu",show_menu)
func resume() -> void:
	clear_overlay()
	get_tree().paused = false
	if not OS.has_feature("Android"): Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
func show_settings() -> void:
	clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(overlay)
	backdrop(overlay,0.94)
	var box := column(overlay,Vector2(85,65),650)
	label(box,"Make yourself at home",42)
	label(box,"Graphics and expedition settings",18)
	option(box,"Shadows",["Off","On"],int(Preferences.shadows),func(i): Preferences.shadows = bool(i))
	option(box,"View distance",["Near · 480 m","Balanced · 672 m","Far · 864 m"],Preferences.view_distance-2,func(i): Preferences.view_distance=i+2)
	option(box,"Vegetation",["Sparse","Balanced","Dense"],[0.35,0.7,1.0].find(Preferences.vegetation),func(i): Preferences.vegetation=[0.35,0.7,1.0][i])
	option(box,"Material detail",["Low","High"],Preferences.texture_quality,func(i): Preferences.texture_quality=i)
	option(box,"3D resolution",["65%","80%","100%"],[0.65,0.8,1.0].find(Preferences.resolution_scale),func(i): Preferences.resolution_scale=[0.65,0.8,1.0][i])
	option(box,"Frame limit",["30 FPS","60 FPS"],int(Preferences.fps==60),func(i): Preferences.fps=[30,60][i])
	option(box,"Next expedition",["Twily","Denzi"],int(Preferences.selected_character=="Denzi"),func(i): Preferences.selected_character=["Twily","Denzi"][i])
	button(box,"Apply & return",func():
		Preferences.apply()
		if playing:
			island.ensure_ground(player.position)
			pause_game()
		else: clear_overlay())
func option(parent: Node,title: String,items: Array,index: int,callback: Callable) -> void:
	var row := HBoxContainer.new()
	parent.add_child(row)
	var l := label(row,title)
	l.custom_minimum_size.x = 280
	var select := OptionButton.new()
	select.custom_minimum_size = Vector2(290,42)
	for item in items: select.add_item(item)
	select.select(index)
	select.item_selected.connect(callback)
	row.add_child(select)
func show_map() -> void:
	pause_game()
	clear_overlay()
	overlay = Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(overlay)
	backdrop(overlay,0.94)
	var box := column(overlay,Vector2(70,35),700)
	box.add_theme_constant_override("separation",5)
	label(box,"Island field guide",38)
	label(box,"Prototype travel points · explore each region on foot",18)
	for i in island.regions.size():
		var r: Dictionary = island.regions[i]
		button(box,"%02d   %s  ·  %s" % [i+1,r.name,r.kind],func(): travel_to(r))
	button(box,"Back to island",resume)
func travel_to(region: Dictionary) -> void:
	var p := Vector3(region.x+6,0,region.z+7)
	p.y = IslandShape.height(p.x,p.z)+1
	island.ensure_ground(p)
	player.position = p
	player.velocity = Vector3.ZERO
	player.rig.global_position = p+Vector3.UP*1.5
	resume()
func _unhandled_input(event: InputEvent) -> void:
	if playing and event.is_action_pressed("pause"):
		if get_tree().paused: resume()
		else: pause_game()
	if playing and not get_tree().paused and event.is_action_pressed("map"): show_map()
