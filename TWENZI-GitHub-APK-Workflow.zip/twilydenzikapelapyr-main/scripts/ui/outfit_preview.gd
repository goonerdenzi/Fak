extends SubViewportContainer
var model: Node3D
var portrait_mode := false
func _ready() -> void:
	custom_minimum_size=Vector2(80,90) if portrait_mode else Vector2(280,380)
	stretch=true
	var viewport:=SubViewport.new()
	viewport.size=Vector2i(80,90) if portrait_mode else Vector2i(280,380)
	viewport.own_world_3d=true
	viewport.transparent_bg=true
	add_child(viewport)
	model=load("res://scripts/player/modular_visual.gd").new()
	model.character_name=Profile.character
	viewport.add_child(model)
	model.apply_outfit(Profile.outfit())
	var camera:=Camera3D.new()
	viewport.add_child(camera)
	camera.position=Vector3(0,1.7,-0.85) if portrait_mode else Vector3(0,1.0,-3.1)
	camera.look_at(Vector3(0,1.7,0) if portrait_mode else Vector3(0,1.0,0))
	camera.fov=38
	var light:=DirectionalLight3D.new()
	light.rotation_degrees=Vector3(-30,-140,0)
	light.light_energy=1.5
	viewport.add_child(light)
	var env:=WorldEnvironment.new()
	env.environment=Environment.new()
	env.environment.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	env.environment.ambient_light_color=Color(0.7,0.8,0.9)
	env.environment.ambient_light_energy=0.65
	viewport.add_child(env)
func _process(delta: float) -> void:
	if model:
		if not portrait_mode: model.rotation.y+=delta*0.22
		model.animate(delta,0,true,0)
