extends Control
var player: CharacterBody3D
var stick_id := -1
var look_id := -1
var origin := Vector2.ZERO
var knob := Vector2.ZERO
var held_run_id := -1
func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func reset() -> void:
	stick_id = -1
	look_id = -1
	if is_instance_valid(player):
		player.touch_move = Vector2.ZERO
		if Preferences.run_hold: player.touch_run=false
	held_run_id=-1
	queue_redraw()
func _input(event: InputEvent) -> void:
	if not is_instance_valid(player) or get_tree().paused or player.input_locked: return
	if event is InputEventScreenTouch:
		# Route every finger independently; GUI mouse emulation alone cannot handle
		# holding the left stick while tapping Jump with a second finger.
		if not event.pressed and event.index==held_run_id:
			player.touch_run=false
			held_run_id=-1
			get_viewport().set_input_as_handled()
			return
		if event.pressed:
			for b in get_parent().find_children("*","Button",true,false):
				if b.is_visible_in_tree() and b.get_global_rect().has_point(event.position):
					if b.text=="Run" and Preferences.run_hold:
						player.touch_run=true
						held_run_id=event.index
					elif b.toggle_mode: b.button_pressed = not b.button_pressed
					else: b.pressed.emit()
					get_viewport().set_input_as_handled()
					return
		if event.pressed and event.position.x<size.x*0.38 and event.position.y>size.y*0.45 and stick_id<0:
			stick_id = event.index
			origin = event.position
			knob = origin
		elif not event.pressed:
			if event.index == stick_id:
				stick_id = -1
				player.touch_move = Vector2.ZERO
			if event.index == look_id: look_id = -1
		elif event.position.x>size.x*0.42 and event.position.y<size.y*0.72 and look_id<0:
			look_id = event.index
	if event is InputEventScreenDrag:
		if event.index == stick_id:
			var offset: Vector2 = (event.position-origin).limit_length(Preferences.joystick_radius)
			knob = origin+offset
			player.touch_move = offset/Preferences.joystick_radius
		if event.index == look_id: player.rig.look(event.relative)
	queue_redraw()
func _draw() -> void:
	var center := origin if stick_id>=0 else Vector2(Preferences.joystick_x,size.y-Preferences.joystick_bottom)
	draw_circle(center,Preferences.joystick_radius,Color(0.85,0.92,0.85,0.08))
	draw_arc(center,Preferences.joystick_radius,0,TAU,64,Color(0.85,0.92,0.85,0.35),2,true)
	draw_circle(knob if stick_id>=0 else center,Preferences.joystick_radius*0.4,Color(0.85,0.92,0.85,0.28))
