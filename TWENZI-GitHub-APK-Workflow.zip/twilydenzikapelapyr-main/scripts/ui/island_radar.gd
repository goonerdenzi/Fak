extends Control
var player: Node3D
var terrain: ImageTexture
func _ready() -> void:
	mouse_filter=Control.MOUSE_FILTER_IGNORE
	var map_image:=Image.create(128,128,false,Image.FORMAT_RGB8)
	for x in 128:
		for y in 128:
			var h:=IslandShape.height(-1200+x/127.0*3800,-1400+y/127.0*2800)
			var color:=Color("17465c") if h<0 else (Color("cfbf86") if h<5 else Color("5c8247").lerp(Color("b9bd97"),clampf(h/230,0,1)))
			map_image.set_pixel(x,y,color)
	terrain=ImageTexture.create_from_image(map_image)
func _process(_delta: float) -> void: queue_redraw()
func _draw() -> void:
	draw_style_box(get_theme_stylebox("normal","Button"),Rect2(Vector2.ZERO,size))
	if terrain: draw_texture_rect(terrain,Rect2(Vector2(5,5),size-Vector2(10,10)),false)
	if is_instance_valid(player):
		var p: Vector2=(Vector2(player.position.x,player.position.z)-Vector2(-1200,-1400))/Vector2(3800,2800)*(size-Vector2(10,10))+Vector2(5,5)
		draw_circle(p,4,Color("ffe2a2"))
		var direction:=Vector2(-sin(player.rig.yaw),-cos(player.rig.yaw))
		draw_line(p,p+direction*12,Color.WHITE,2)
