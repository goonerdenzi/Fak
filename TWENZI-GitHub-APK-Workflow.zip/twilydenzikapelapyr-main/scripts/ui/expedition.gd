extends "res://scripts/ui/main.gd"
var hotbar: HBoxContainer
var status: Label
var compass: Label
var clock_label: Label
var radar: Control
var inventory_selection := -1
var inventory_category := "All"
var move_source := -1
var panel_content: VBoxContainer
var detail: Label
var preview_model: Control
var wardrobe_slot := "upper"
var local_drops: Array[Node3D] = []
var portrait: Control
var health_bar: ProgressBar
var open_panel := ""
var peer_label: Label

func session() -> Node: return get_node_or_null("/root/Session")
func online() -> bool: return session()!=null and session().active
func _ready() -> void:
	super._ready()
	Profile.outfit_changed.connect(outfit_updated)
	Profile.inventory.changed.connect(refresh_hotbar)
	if session(): session().app=self
func start_game() -> void:
	Profile.character=Preferences.selected_character
	super.start_game()
	player.visual.apply_outfit(Profile.outfit())
	refresh_hotbar()
func show_menu() -> void:
	if online(): session().leave()
	if is_instance_valid(player): player.input_locked=false
	super.show_menu()
	var box: VBoxContainer=menu.get_child(1)
	var multiplayer_button:=button(box,"Private expedition · Host / Join",show_network_panel)
	box.move_child(multiplayer_button,6)
func panel(title: String) -> VBoxContainer:
	open_panel=""
	pause_game()
	clear_overlay()
	overlay=Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.add_child(overlay)
	backdrop(overlay,0.94)
	var box:=column(overlay,Vector2(45,32),1000)
	label(box,title,36)
	panel_content=box
	return box
func make_hud() -> void:
	hud=Control.new()
	hud.mouse_filter=Control.MOUSE_FILTER_IGNORE
	ui.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.modulate.a=Preferences.hud_opacity
	touch=load("res://scripts/ui/touch_controls.gd").new()
	touch.player=player
	hud.add_child(touch)
	info=label(hud,"",22)
	info.position=Vector2(130,24)
	portrait=load("res://scripts/ui/outfit_preview.gd").new()
	portrait.portrait_mode=true
	hud.add_child(portrait)
	portrait.position=Vector2(30,20)
	portrait.size=Vector2(80,90)
	health_bar=ProgressBar.new()
	health_bar.show_percentage=false
	health_bar.position=Vector2(130,110)
	health_bar.size=Vector2(220,10)
	hud.add_child(health_bar)
	status=label(hud,"",18)
	status.position=Vector2(130,87)
	prompt=label(hud,"",18)
	prompt.position=Vector2(32,138)
	toast=label(hud,"Our little world · follow the shoreline",17)
	toast.position=Vector2(32,175)
	compass=label(hud,"",20)
	compass.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	compass.offset_left=-180
	compass.offset_top=24
	peer_label=label(hud,"",16)
	peer_label.position=Vector2(32,213)
	var shortcuts:=HBoxContainer.new()
	hud.add_child(shortcuts)
	shortcuts.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	shortcuts.offset_left=-620
	shortcuts.offset_right=-24
	shortcuts.offset_top=62
	for pair in [["Inventory",show_inventory],["Outfit",show_outfit],["Craft",show_craft],["Map",show_map],["Pause",pause_game]]:
		var b:=button(shortcuts,pair[0],pair[1])
		b.add_theme_font_size_override("font_size",17)
	radar=load("res://scripts/ui/island_radar.gd").new()
	radar.player=player
	hud.add_child(radar)
	radar.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	radar.offset_left=-194; radar.offset_right=-24; radar.offset_top=126; radar.offset_bottom=296
	clock_label=label(hud,"",16)
	clock_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	clock_label.offset_left=-194; clock_label.offset_top=300
	hotbar=HBoxContainer.new()
	hud.add_child(hotbar)
	hotbar.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	hotbar.offset_left=-264; hotbar.offset_right=264; hotbar.offset_top=-100; hotbar.offset_bottom=-26
	hotbar.add_theme_constant_override("separation",5)
	for i in range(6):
		var b:=button(hotbar,str(i+1),func(): select_hotbar(i))
		b.custom_minimum_size=Vector2(82,70)
		b.expand_icon=true
		b.add_theme_constant_override("icon_max_width",32)
		b.add_theme_stylebox_override("normal",compact_style())
	var actions:=GridContainer.new()
	actions.name="Actions"
	actions.columns=2
	actions.add_theme_constant_override("h_separation",8)
	actions.add_theme_constant_override("v_separation",8)
	hud.add_child(actions)
	actions.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	actions.offset_left=-320-Preferences.action_offset.x
	actions.offset_right=-24-Preferences.action_offset.x
	actions.offset_top=-235-Preferences.action_offset.y
	actions.offset_bottom=-110-Preferences.action_offset.y
	button(actions,"View",func(): player.rig.switch_view())
	var run:=button(actions,"Run",func(): pass)
	run.toggle_mode=not Preferences.run_hold
	run.toggled.connect(func(value: bool): player.touch_run=value)
	run.button_down.connect(func():
		if Preferences.run_hold: player.touch_run=true)
	run.button_up.connect(func():
		if Preferences.run_hold: player.touch_run=false)
	button(actions,"Jump",func(): player.jump_queued=true)
	button(actions,"Interact",interact)
	button(actions,"Use",func(): inventory_action("use",Profile.inventory.selected))
	for b in actions.get_children(): b.custom_minimum_size=Vector2(130,52)*Preferences.button_scale
	refresh_hotbar()
func refresh_hotbar() -> void:
	if open_panel=="inventory": refresh_inventory_panel.call_deferred()
	if not is_instance_valid(hotbar): return
	if is_instance_valid(player): player.visual.equip_tool(Profile.inventory.active_tool)
	for i in 6:
		var b: Button=hotbar.get_child(i)
		var item: Dictionary=Profile.inventory.slots[i]
		b.text=str(i+1) if item.is_empty() else str(int(item.quantity))
		b.icon=null if item.is_empty() else load("res://assets/icons/%s.svg"%Profile.inventory.definitions[item.id].icon)
		b.modulate=Color("ffe0a0") if i==Profile.inventory.selected else Color.WHITE
func refresh_inventory_panel() -> void:
	if open_panel=="inventory" and is_instance_valid(overlay): show_inventory()
func select_hotbar(index: int) -> void:
	Profile.inventory.selected=index
	if not online():
		var item: Dictionary=Profile.inventory.slots[index]
		Profile.inventory.active_tool=item.id if not item.is_empty() and Profile.inventory.definitions[item.id].get("tool",false) else ""
	Profile.inventory.changed.emit()
	if online(): session().inventory_request("select",index)
func _process(delta: float) -> void:
	super._process(delta)
	if not playing or not is_instance_valid(player) or not is_instance_valid(status): return
	health_bar.value=Profile.inventory.health
	status.text="HEALTH  %d / 100     ·     Lv. —"%Profile.inventory.health
	var degrees:=fposmod(rad_to_deg(-player.rig.yaw),360)
	var cardinals: Array=["N","NE","E","SE","S","SW","W","NW"]
	var heading:=int((degrees+22.5)/45.0)%8
	compass.text="%s    ·    %s  %03d°    ·    %s"%[cardinals[(heading+7)%8],cardinals[heading],int(degrees),cardinals[(heading+1)%8]]
	var minutes: int=int(island.world_minutes)
	clock_label.text="%02d:%02d  ·  Clear"%[minutes/60,minutes%60]
	peer_label.text="Private party  %d / 4 · %s"%[session().actors.size(),session().room_code] if online() else "Solo expedition"
	for drop in local_drops:
		if is_instance_valid(drop) and player.position.distance_to(drop.position)<3:
			prompt.text="Interact · pick up "+str(drop.get_meta("item").id)
	if online():
		for drop in session().drops.values():
			if player.position.distance_to(drop.position)<3: prompt.text="Interact · pick up "+str(drop.item.id)
func pause_game() -> void:
	if not playing: return
	super.pause_game()
	player.input_locked=true
	if online(): get_tree().paused=false
func resume() -> void:
	open_panel=""
	if is_instance_valid(player): player.input_locked=false
	super.resume()
func show_inventory() -> void:
	var box:=panel("Satchel  /  Inventory")
	open_panel="inventory"
	var tabs:=HBoxContainer.new()
	box.add_child(tabs)
	for category in ["All","Resources","Food","Tools","Equipment","Clothing","Accessories","Quest items","Miscellaneous"]:
		var b:=button(tabs,category,func(): inventory_category=category; show_inventory())
		b.add_theme_font_size_override("font_size",14)
		b.add_theme_stylebox_override("normal",compact_style())
	var row:=HBoxContainer.new()
	row.add_theme_constant_override("separation",24)
	box.add_child(row)
	var grid:=GridContainer.new()
	grid.columns=6
	grid.add_theme_constant_override("h_separation",6)
	grid.add_theme_constant_override("v_separation",6)
	row.add_child(grid)
	for i in InventoryModel.CAPACITY:
		var item: Dictionary=Profile.inventory.slots[i]
		var b:=button(grid,"—",func(): choose_inventory(i))
		b.custom_minimum_size=Vector2(92,96)
		b.expand_icon=true
		b.add_theme_constant_override("icon_max_width",42)
		b.add_theme_stylebox_override("normal",compact_style())
		if not item.is_empty():
			var def: Dictionary=Profile.inventory.definitions[item.id]
			b.icon=load("res://assets/icons/%s.svg"%def.icon)
			b.text=str(int(item.quantity))
			b.tooltip_text=def.name
			if inventory_category!="All" and inventory_category!=def.category: b.modulate.a=0.25
		if i==inventory_selection: b.modulate=Color("ffe0a0")
	var side:=column(row,Vector2.ZERO,380)
	detail=label(side,"Select an item",20)
	detail.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	detail.custom_minimum_size=Vector2(360,180)
	if inventory_selection>=0 and not Profile.inventory.slots[inventory_selection].is_empty():
		var item: Dictionary=Profile.inventory.slots[inventory_selection]
		var def: Dictionary=Profile.inventory.definitions[item.id]
		detail.text="%s\n%s · %d / %d\n\n%s"%[def.name,def.category,item.quantity,def.max_stack,def.description]
	button(side,"Use / Equip",func(): inventory_action("use",inventory_selection); show_inventory())
	button(side,"Move · then choose destination",func(): move_source=inventory_selection; detail.text="Choose a destination slot. Matching stacks merge.")
	button(side,"Split stack",func(): inventory_action("split",inventory_selection); show_inventory())
	button(side,"Drop one",func(): inventory_action("drop",inventory_selection); show_inventory())
	var occupied:=0
	for item in Profile.inventory.slots:
		if not item.is_empty(): occupied+=1
	label(box,"%d / 24 slots occupied  ·  First six slots appear in the hotbar"%occupied,17)
	button(box,"Close",resume)
func compact_style() -> StyleBoxFlat:
	var style:=StyleBoxFlat.new()
	style.bg_color=Color("254449")
	style.set_content_margin_all(9)
	style.set_corner_radius_all(4)
	return style
func choose_inventory(index: int) -> void:
	if move_source>=0:
		inventory_action("move",move_source,index)
		move_source=-1
	inventory_selection=index
	show_inventory()
func inventory_action(operation: String,index: int,to: int=-1) -> void:
	if online(): session().inventory_request(operation,index,to); return
	var bag: InventoryModel=Profile.inventory
	match operation:
		"move": bag.move(index,to)
		"split": bag.split(index)
		"drop":
			var item:=bag.drop(index)
			if not item.is_empty(): spawn_local_drop(item,player.position+Vector3(1,0.5,0))
		"use":
			var result:=bag.use(index)
			if result.has("message"): toast.text=result.message
			if result.has("outfit"): Profile.equip(ClothingCatalog.definitions()[result.outfit].slot,result.outfit)
			if result.has("tool"): use_tool(player,bag,result.tool)
			player.visual.trigger_action("interact")
func spawn_local_drop(item: Dictionary,pos: Vector3) -> void:
	var drop:=make_drop(item,pos)
	local_drops.append(drop)
func make_drop(item: Dictionary,pos: Vector3) -> Node3D:
	var drop:=Node3D.new()
	island.add_child(drop)
	drop.position=pos
	drop.set_meta("item",item)
	var mesh:=MeshInstance3D.new()
	var box:=BoxMesh.new()
	box.size=Vector3(0.25,0.20,0.25)
	mesh.mesh=box
	var mat:=StandardMaterial3D.new()
	mat.albedo_color=Color("cfb681")
	mesh.material_override=mat
	drop.add_child(mesh)
	var text:=Label3D.new()
	text.text=Profile.inventory.definitions[item.id].name+" ×"+str(item.quantity)
	text.position.y=0.5
	text.font_size=32
	text.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	drop.add_child(text)
	return drop
func use_tool(actor: Node3D,bag: InventoryModel,tool: String) -> void:
	var now:=Time.get_ticks_msec()
	if now<int(actor.get_meta("tool_next",0)): return
	actor.set_meta("tool_next",now+800)
	actor.visual.equip_tool(tool)
	var found:=false
	for chunk in island.chunks.values():
		if chunk.position.distance_to(actor.position)>160: continue
		for child in chunk.get_children():
			if child is MultiMeshInstance3D:
				var target_mesh: Mesh=island.rock if tool=="pick" else island.palm
				if child.multimesh.mesh!=target_mesh and (tool=="pick" or child.multimesh.mesh!=island.jungle): continue
				for i in child.multimesh.instance_count:
					if actor.position.distance_to(child.global_transform*child.multimesh.get_instance_transform(i).origin)<5:
						found=true
		if found: break
	if found:
		bag.add("stone" if tool=="pick" else "wood",1)
		toast.text="Collected a sample. Full gathering comes in a later part."
	else: toast.text="Move within 5 m of a rock or tree to use this tool."
func interact() -> void:
	if online():
		session().pickup_request()
		super.interact()
		return
	for drop in local_drops:
		if is_instance_valid(drop) and player.position.distance_to(drop.position)<3:
			var item: Dictionary=drop.get_meta("item")
			var remaining:=Profile.inventory.add(item.id,item.quantity)
			if remaining==0:
				local_drops.erase(drop)
				drop.queue_free()
			else:
				drop.set_meta("item",{"id":item.id,"quantity":remaining})
				for node in drop.get_children():
					if node is Label3D: node.text=Profile.inventory.definitions[item.id].name+" ×"+str(remaining)
			return
	super.interact()
	player.visual.trigger_action()
func outfit_updated(config: Dictionary) -> void:
	if online(): session().request_outfit(config)
	elif is_instance_valid(player): player.visual.apply_outfit(config)
	if is_instance_valid(portrait) and portrait.model: portrait.model.apply_outfit(config)
	if is_instance_valid(preview_model) and preview_model.model: preview_model.model.apply_outfit(config)
func show_outfit() -> void:
	var box:=panel("Wardrobe  /  "+Profile.character)
	var row:=HBoxContainer.new()
	row.add_theme_constant_override("separation",20)
	box.add_child(row)
	preview_model=load("res://scripts/ui/outfit_preview.gd").new()
	row.add_child(preview_model)
	var choices:=column(row,Vector2.ZERO,630)
	var tabs:=HBoxContainer.new()
	choices.add_child(tabs)
	for slot in ClothingCatalog.SLOTS:
		var b:=button(tabs,slot.capitalize(),func(): wardrobe_slot=slot; show_outfit())
		b.add_theme_font_size_override("font_size",14)
		b.add_theme_stylebox_override("normal",compact_style())
	label(choices,"Choose "+wardrobe_slot+" · changes update the 3D character",18)
	for id in ClothingCatalog.definitions():
		var item: Dictionary=ClothingCatalog.definitions()[id]
		if item.slot!=wardrobe_slot: continue
		button(choices,("✓  " if Profile.outfit()[wardrobe_slot]==id else "")+str(item.name),func(): Profile.equip(wardrobe_slot,id); show_outfit())
	button(choices,"Unequip "+wardrobe_slot,func(): Profile.equip(wardrobe_slot,""); show_outfit())
	var title:=LineEdit.new()
	title.placeholder_text="Outfit name"
	title.max_length=32
	choices.add_child(title)
	button(choices,"Save outfit",func():
		if Profile.save_outfit(title.text): show_outfit())
	var saved:=OptionButton.new()
	choices.add_child(saved)
	saved.add_item("Load a saved outfit…")
	for key in Profile.saved_outfits:
		if key.begins_with(Profile.character+":"): saved.add_item(key.get_slice(":",1))
	saved.item_selected.connect(func(i: int):
		if i>0: Profile.load_outfit(saved.get_item_text(i)); show_outfit())
	button(box,"Close",resume)
func show_craft() -> void:
	var box:=panel("Crafting field notes")
	label(box,"Crafting unlocks in a later part. Your resources are already stored in the satchel.",20)
	button(box,"Open inventory",show_inventory)
	button(box,"Close",resume)
func show_settings() -> void:
	super.show_settings()
	if playing:
		var box: VBoxContainer=overlay.get_child(1)
		button(box,"Customize controls",show_controls)
		button(box,"Daylight / Sunset",func(): island.set_sunset(not island.sunset))
func show_controls() -> void:
	var box:=panel("Make the controls yours")
	for setting in [["Button size","button_scale",0.8,1.2],["HUD opacity","hud_opacity",0.4,1.0],["Look sensitivity","sensitivity",0.5,2.0],["Joystick size","joystick_radius",45.0,90.0],["Joystick horizontal","joystick_x",90.0,220.0],["Joystick bottom offset","joystick_bottom",140.0,260.0],["Actions horizontal offset","action_x",0.0,80.0],["Actions bottom offset","action_y",0.0,120.0]]:
		label(box,setting[0],16)
		var slider:=HSlider.new()
		slider.min_value=setting[2]; slider.max_value=setting[3]; slider.step=0.01
		slider.value=Preferences.get(setting[1])
		slider.custom_minimum_size=Vector2(650,24)
		slider.value_changed.connect(func(value: float): Preferences.set(setting[1],value))
		box.add_child(slider)
	option(box,"Run mode",["Toggle","Hold"],int(Preferences.run_hold),func(i): Preferences.run_hold=bool(i))
	button(box,"Reset controls",func(): Preferences.reset_controls(); show_controls())
	button(box,"Apply & close",func():
		Preferences.apply()
		island.ensure_ground(player.position)
		hud.queue_free()
		make_hud()
		resume())
func show_network_panel() -> void:
	clear_overlay()
	overlay=Control.new()
	ui.add_child(overlay)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	backdrop(overlay,0.96)
	var box:=column(overlay,Vector2(70,45),680)
	label(box,"Private expedition",38)
	label(box,"2–4 players · Direct IP / LAN\nA room code is a join secret, not an internet relay.",19)
	var name_input:=LineEdit.new()
	name_input.placeholder_text="Player name"; name_input.text=Preferences.selected_character; name_input.max_length=24
	box.add_child(name_input)
	var address:=LineEdit.new()
	address.placeholder_text="Host IP address"; address.text="127.0.0.1"
	box.add_child(address)
	var port:=SpinBox.new()
	port.min_value=1024; port.max_value=65535; port.value=24567
	box.add_child(port)
	var code:=LineEdit.new()
	code.placeholder_text="Room code (joining only)"; code.max_length=16
	box.add_child(code)
	var message:=label(box,"Host shares their IP, port and generated code.",18)
	button(box,"Host",func():
		if session():
			start_game()
			var err: int=session().host(int(port.value),name_input.text)
			if err!=OK: toast.text="Hosting failed: "+error_string(err))
	button(box,"Join",func():
		if session():
			var ip:=address.text.strip_edges()
			var room:=code.text.strip_edges()
			var username:=name_input.text
			var target_port:=int(port.value)
			if ip.is_empty() or room.is_empty(): message.text="Enter the host IP and room code."; return
			start_game()
			session().join(ip,target_port,room,username))
	button(box,"Back",clear_overlay)
func _unhandled_input(event: InputEvent) -> void:
	super._unhandled_input(event)
	if not playing or get_tree().paused or player.input_locked: return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode>=KEY_1 and event.physical_keycode<=KEY_6: select_hotbar(event.physical_keycode-KEY_1)
		if event.physical_keycode==KEY_I: show_inventory()
		if event.physical_keycode==KEY_O: show_outfit()
		if event.physical_keycode==KEY_F: inventory_action("use",Profile.inventory.selected)

func show_map() -> void:
	var box:=panel("Island field guide")
	label(box,"14 connected regions · prototype travel points",18)
	var scroll:=ScrollContainer.new()
	scroll.custom_minimum_size=Vector2(1000,610)
	box.add_child(scroll)
	var places:=VBoxContainer.new()
	places.custom_minimum_size.x=960
	scroll.add_child(places)
	for region in island.regions:
		button(places,region.name+"  ·  "+region.kind,func(): travel_to(region))
	button(box,"Close",resume)
func travel_to(region: Dictionary) -> void:
	if online():
		session().travel_request(island.regions.find(region))
		resume()
	else: super.travel_to(region)
