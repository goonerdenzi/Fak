extends Node3D
@export var character_name := "Twily"
var skeleton: Skeleton3D
var slots: Dictionary = {}
var equipment: Dictionary = {}
var animation_state := "idle"
var phase := 0.0
var blend := 0.0
var action_time := 0.0
var action := "interact"
var was_grounded := true
var landing := 0.0
var eyes: Array[Node3D] = []
var bones: Dictionary = {}
var expression := "neutral"

func _ready() -> void:
	skeleton=Skeleton3D.new()
	skeleton.name="Skeleton3D"
	add_child(skeleton)
	bone("Root",-1,Vector3.ZERO)
	bone("Hips",0,Vector3(0,0.93,0))
	bone("Spine",1,Vector3(0,0.19,0))
	bone("Chest",2,Vector3(0,0.23,0))
	bone("Neck",3,Vector3(0,0.18,0))
	bone("Head",4,Vector3(0,0.12,0))
	for sign_value in [-1,1]:
		var side: String="L" if sign_value<0 else "R"
		bone("Arm"+side,3,Vector3(sign_value*(0.24 if character_name=="Twily" else 0.265),0.04,0))
		bone("Elbow"+side,bones["Arm"+side],Vector3(0,-0.27,0))
		bone("Hand"+side,bones["Elbow"+side],Vector3(0,-0.25,0))
		bone("Thigh"+side,1,Vector3(sign_value*0.105,-0.02,0))
		bone("Knee"+side,bones["Thigh"+side],Vector3(0,-0.43,0))
		bone("Foot"+side,bones["Knee"+side],Vector3(0,-0.40,-0.035))
	var skin:=Color("c69576") if character_name=="Twily" else Color("bd8761")
	shape(attach("Spine"),Vector3(0,0.04,0),Vector3(0.18,0.24,0.12),Color("e6d7bb"))
	shape(attach("Neck"),Vector3(0,0.02,0),Vector3(0.062,0.10,0.064),skin)
	var head:=attach("Head")
	shape(head,Vector3(0,0.06,0),Vector3(0.115 if character_name=="Twily" else 0.122,0.155,0.108),skin)
	shape(head,Vector3(0,0.037,-0.107),Vector3(0.021 if character_name=="Twily" else 0.026,0.029,0.029),skin)
	shape(head,Vector3(0,-0.019,-0.098),Vector3(0.037,0.008,0.009),Color("9b6256"))
	for side in [-1,1]:
		shape(head,Vector3(side*0.116,0.045,0),Vector3(0.024,0.044,0.023),skin)
		var eye:=shape(head,Vector3(side*0.045,0.075,-0.096),Vector3(0.028,0.014,0.014),Color("e7ddd1"))
		eyes.append(eye)
		shape(head,Vector3(side*0.045,0.075,-0.108),Vector3(0.012,0.012,0.007),Color("382a22"))
		shape(head,Vector3(side*0.046,0.103,-0.100),Vector3(0.031,0.006,0.008),Color("463027"))
		var suffix: String="L" if side<0 else "R"
		shape(attach("Arm"+suffix),Vector3(0,-0.13,0),Vector3(0.063,0.155,0.060),skin)
		shape(attach("Elbow"+suffix),Vector3(0,-0.12,0),Vector3(0.050,0.145,0.048),skin)
		shape(attach("Hand"+suffix),Vector3(0,-0.045,0),Vector3(0.043,0.069,0.027),skin)
		shape(attach("Thigh"+suffix),Vector3(0,-0.21,0),Vector3(0.092,0.25,0.085),skin)
		shape(attach("Knee"+suffix),Vector3(0,-0.18,0),Vector3(0.059,0.22,0.057),skin)
	for slot in ClothingCatalog.SLOTS:
		var group:=Node3D.new()
		group.name=slot
		add_child(group)
		slots[slot]=group
	apply_outfit(ClothingCatalog.defaults(character_name))

func bone(title: String,parent: int,pos: Vector3) -> void:
	var index:=skeleton.get_bone_count()
	skeleton.add_bone(title)
	bones[title]=index
	if parent>=0: skeleton.set_bone_parent(index,parent)
	skeleton.set_bone_rest(index,Transform3D(Basis.IDENTITY,pos))
	skeleton.set_bone_pose_position(index,pos)

func attach(title: String,group: Node=null) -> BoneAttachment3D:
	var attachment:=BoneAttachment3D.new()
	if group:
		group.add_child(attachment)
		attachment.use_external_skeleton=true
		attachment.external_skeleton=attachment.get_path_to(skeleton)
	else: skeleton.add_child(attachment)
	attachment.bone_name=title
	return attachment

func shape(parent: Node,pos: Vector3,size: Vector3,color: Color) -> MeshInstance3D:
	var m:=MeshInstance3D.new()
	var sphere:=SphereMesh.new()
	sphere.radius=1.0
	sphere.height=2.0
	sphere.radial_segments=16
	sphere.rings=8
	m.mesh=sphere
	m.position=pos
	m.scale=size
	var material:=StandardMaterial3D.new()
	material.albedo_color=color
	material.roughness=0.87
	m.material_override=material
	parent.add_child(m)
	return m

func apply_outfit(config: Dictionary) -> bool:
	if not ClothingCatalog.valid(config): return false
	var previous:=equipment
	equipment=config.duplicate(true)
	for slot in ClothingCatalog.SLOTS:
		if previous.get(slot,null)==config[slot]: continue
		var group: Node=slots[slot]
		for node in group.get_children():
			group.remove_child(node)
			node.queue_free()
		var id: String=config[slot]
		if id.is_empty(): continue
		var item: Dictionary=ClothingCatalog.definitions()[id]
		var color:=Color(item.color)
		match slot:
			"hair":
				var head:=attach("Head",group)
				shape(head,Vector3(0,0.16,0.016),Vector3(0.125,0.084,0.115),color)
				for i in range(18):
					var a:=float(i)*TAU/18
					var bob: bool=item.style=="bob"
					if bob and sin(a)<-0.65: continue
					var lock:=shape(head,Vector3(cos(a)*0.1,0.055 if bob else 0.16+sin(float(i)*4.3)*0.025,sin(a)*0.09+0.02),Vector3(0.048,0.145 if bob else 0.065+float(i%3)*0.012,0.047),color.lightened(float(i%3)*0.035))
					lock.rotation.z=cos(a)*(0.13 if bob else 0.65)
			"head":
				var head:=attach("Head",group)
				if id=="cap_sage":
					shape(head,Vector3(0,0.18,0),Vector3(0.135,0.065,0.13),color)
					shape(head,Vector3(0,0.16,-0.12),Vector3(0.13,0.015,0.09),color)
				else:
					var clip:=shape(head,Vector3(-0.105,0.13,-0.07),Vector3(0.009,0.039,0.01),color)
					clip.rotation.z=0.7
			"upper":
				var chest:=attach("Chest",group)
				shape(chest,Vector3(0,-0.12,0),Vector3(0.216 if character_name=="Twily" else 0.235,0.285,0.145),color)
				shape(chest,Vector3(0,0.10,0.085),Vector3(0.125,0.09,0.085),Color("e2d3b7"))
				shape(chest,Vector3(0,-0.14,-0.143),Vector3(0.006,0.22,0.006),Color("e7ddbf"))
				for side in ["L","R"]:
					var sleeve: Color=Color("d7c9ac") if item.style=="varsity" else color
					shape(attach("Arm"+side,group),Vector3(0,-0.12,0),Vector3(0.079,0.17,0.076),sleeve)
					shape(attach("Elbow"+side,group),Vector3(0,-0.105,0),Vector3(0.064,0.14,0.061),sleeve)
			"lower":
				shape(attach("Hips",group),Vector3(0,-0.03,0),Vector3(0.19,0.13,0.13),color)
				for side in ["L","R"]:
					shape(attach("Thigh"+side,group),Vector3(0,-0.12,0),Vector3(0.105,0.20,0.10),color)
					if item.style=="trousers": shape(attach("Knee"+side,group),Vector3(0,-0.18,0),Vector3(0.068,0.22,0.066),color)
			"shoes":
				for side in ["L","R"]:
					var foot:=attach("Foot"+side,group)
					shape(foot,Vector3(0,0.025,-0.04),Vector3(0.072,0.064,0.13),color)
					shape(foot,Vector3(0,-0.014,-0.04),Vector3(0.074,0.023,0.132),Color("dcd9c9"))
			"backpack":
				var back:=attach("Chest",group)
				shape(back,Vector3(0,-0.12,0.22),Vector3(0.17,0.23,0.10),color)
				shape(back,Vector3(0,-0.23,0.31),Vector3(0.12,0.07,0.04),color.darkened(0.12))
				for sign_value in [-1,1]: shape(back,Vector3(sign_value*0.125,-0.08,-0.135),Vector3(0.018,0.21,0.018),color)
			"accessory":
				var anchor:=attach("HandL" if id=="watch" else "Chest",group)
				shape(anchor,Vector3(0,0,0.035) if id=="watch" else Vector3(0.15,-0.28,0.31),Vector3(0.032,0.034,0.018),color)
	return true

func trigger_action(name_value: String="interact") -> void:
	action=name_value
	action_time=0.75
func pose(title: String,angle: Vector3,delta: float) -> void:
	var id: int=bones[title]
	skeleton.set_bone_pose_rotation(id,skeleton.get_bone_pose_rotation(id).slerp(Quaternion.from_euler(angle),1.0-exp(-delta*12)))
func animate(delta: float,speed: float,grounded: bool,vertical: float) -> void:
	phase+=delta*(5.0+speed)
	blend=lerpf(blend,clampf(speed/6,0,1),1.0-exp(-delta*8))
	animation_state="run" if speed>4.5 else ("walk" if speed>0.2 else "idle")
	if not grounded: animation_state="jump" if vertical>0 else "fall"
	if grounded and not was_grounded: landing=0.2
	was_grounded=grounded
	landing=maxf(0,landing-delta)
	if landing>0: animation_state="landing"
	action_time=maxf(0,action_time-delta)
	if action_time>0: animation_state=action
	for i in range(2):
		var suffix: String="L" if i==0 else "R"
		var swing:=sin(phase+PI*i)*blend
		pose("Thigh"+suffix,Vector3(swing*0.65 if grounded else -0.38,0,0),delta)
		pose("Knee"+suffix,Vector3(-maxf(0,-swing)*0.9 if grounded else -0.8,0,0),delta)
		pose("Arm"+suffix,Vector3(-swing*0.55 if grounded else 0.65,0,0),delta)
		pose("Elbow"+suffix,Vector3(0.15+blend*0.4,0,0),delta)
	if action_time>0:
		pose("ArmR",Vector3(1.3,0,-0.15),delta)
		pose("ElbowR",Vector3(0.65+sin(action_time*12)*0.15,0,0),delta)
	pose("Spine",Vector3(landing*0.7,0,sin(phase*0.5)*blend*0.04),delta)
	pose("Chest",Vector3(sin(phase*0.3)*0.012,0,0),delta)
	for eye in eyes: eye.scale.y=0.014*(0.15 if fmod(phase,30.0)>29.6 else 1.0)

var held_tool := ""
var tool_group: Node3D
func equip_tool(id: String) -> bool:
	if id not in ["","axe","pick"]: return false
	if held_tool==id: return true
	held_tool=id
	if is_instance_valid(tool_group):
		remove_child(tool_group)
		tool_group.queue_free()
	tool_group=Node3D.new()
	add_child(tool_group)
	if id.is_empty(): return true
	var hand:=attach("HandR",tool_group)
	shape(hand,Vector3(0,-0.05,-0.12),Vector3(0.018,0.018,0.24),Color("987047"))
	var head:=MeshInstance3D.new()
	var mesh:=BoxMesh.new()
	mesh.size=Vector3(0.16 if id=="axe" else 0.30,0.09 if id=="axe" else 0.035,0.045)
	head.mesh=mesh
	head.position=Vector3(0,-0.05,-0.32)
	var material:=StandardMaterial3D.new()
	material.albedo_color=Color("879b9d")
	material.metallic=0.5
	material.roughness=0.4
	head.material_override=material
	hand.add_child(head)
	return true
