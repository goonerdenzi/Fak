extends CharacterBody3D
signal interaction_requested
@export var character_name := "Twily"
@export var walk_speed := 3.5
@export var run_speed := 7.0
@export var jump_speed := 6.0
@export var gravity := 18.0
var touch_move := Vector2.ZERO
var touch_run := false
var jump_queued := false
var visual: Node3D
var rig: Node3D
var command := {"move":Vector2.ZERO,"jump":false,"run":false}
var remote_controlled := false
var network_id := 0
var display_name := ""
var net_command := {"move":Vector2.ZERO,"run":false,"jump":false}
var net_target := Vector3.ZERO
var net_grounded := true
var input_locked := false
var was_grounded := true
var locomotion_state := "idle"
func _ready() -> void:
	visual = $Visual
	rig = load("res://scripts/camera/player_camera.gd").new()
	rig.target = self
	add_child(rig)
	rig.global_position = global_position+Vector3.UP*1.5
	floor_snap_length = 0.4
	floor_max_angle = deg_to_rad(48)
func _physics_process(delta: float) -> void:
	if remote_controlled:
		if multiplayer.is_server():
			apply_command(net_command,delta)
			net_command.jump=false
		else:
			if net_target!=Vector3.ZERO: position=position.lerp(net_target,1.0-exp(-delta*18))
			visual.animate(delta,Vector2(velocity.x,velocity.z).length(),net_grounded,velocity.y)
		return
	# Input commands are isolated here for future network ownership/serialization.
	command.move = (Input.get_vector("left","right","forward","back")+touch_move).limit_length()
	command.run = Input.is_action_pressed("run") or touch_run
	command.jump = Input.is_action_just_pressed("jump") or jump_queued
	jump_queued = false
	if input_locked: command={"move":Vector2.ZERO,"run":false,"jump":false}
	apply_command(command,delta)
	Session.submit_local(command,rig.yaw)
func apply_command(input: Dictionary,delta: float) -> void:
	var direction := Basis(Vector3.UP,rig.yaw)*Vector3(input.move.x,0,input.move.y)
	var speed: float = run_speed if input.run else walk_speed
	velocity.x = move_toward(velocity.x,direction.x*speed,delta*22)
	velocity.z = move_toward(velocity.z,direction.z*speed,delta*22)
	if not is_on_floor(): velocity.y -= gravity*delta
	if input.jump and is_on_floor(): velocity.y = jump_speed
	# Water traversal foundation; full swimming animation/stamina belongs to a later part.
	if global_position.y < -0.7:
		velocity.y = maxf(velocity.y,2.5)
		velocity.x *= 0.96
		velocity.z *= 0.96
	move_and_slide()
	if direction.length()>0.1: visual.rotation.y = lerp_angle(visual.rotation.y,atan2(-direction.x,-direction.z),1.0-exp(-delta*10))
	visual.animate(delta,Vector2(velocity.x,velocity.z).length(),is_on_floor(),velocity.y)
	locomotion_state = visual.animation_state
	if is_on_floor() and not was_grounded: locomotion_state = "landing"
	was_grounded = is_on_floor()
func _unhandled_input(event: InputEvent) -> void:
	if input_locked or remote_controlled: return
	if event.is_action_pressed("camera"): rig.switch_view()
	if event.is_action_pressed("interact"): interaction_requested.emit()
