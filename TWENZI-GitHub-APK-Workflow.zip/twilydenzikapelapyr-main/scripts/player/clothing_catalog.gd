class_name ClothingCatalog
extends RefCounted
const SLOTS := ["hair","head","upper","lower","shoes","backpack","accessory"]
static var items: Dictionary = {}
static func definitions() -> Dictionary:
	if items.is_empty(): items=JSON.parse_string(FileAccess.get_file_as_string("res://data/clothing.json"))
	return items
static func defaults(character: String) -> Dictionary:
	if character=="Denzi": return {"hair":"hair_tousled","head":"","upper":"varsity_red","lower":"cargo_dark","shoes":"shoes_brown","backpack":"pack_dark","accessory":"watch"}
	return {"hair":"hair_bob","head":"clip_cream","upper":"hoodie_purple","lower":"shorts_dark","shoes":"shoes_purple","backpack":"pack_tan","accessory":"flower_charm"}
static func valid(config: Dictionary) -> bool:
	if config.size()!=SLOTS.size(): return false
	for slot in SLOTS:
		if not config.has(slot) or not config[slot] is String: return false
		var id: String=config[slot]
		if id.is_empty(): continue
		if not definitions().has(id) or definitions()[id].slot!=slot: return false
	return true
