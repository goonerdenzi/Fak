extends Node3D
@export var shirt := Color(0.35,0.48,0.39)
@export var skin := Color(0.56,0.36,0.23)
var limbs: Array[Node3D] = []
var phase := 0.0
var blend := 0.0
var animation_state := "idle"
var skeleton: Skeleton3D

func part(parent: Node3D,pos: Vector3,size: Vector3,color: Color) -> void:
	var item := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = size.x
	mesh.height = size.y
	mesh.radial_segments = 12
	mesh.rings = 4
	item.mesh = mesh
	item.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.85
	item.material_override = mat
	parent.add_child(item)

func _ready() -> void:
	# Named skeleton is the replacement seam for authored, skinned models.
	skeleton = Skeleton3D.new()
	skeleton.name = "Skeleton3D"
	add_child(skeleton)
	for bone in ["Root","Hips","Spine","Head","ArmL","ArmR","LegL","LegR"]:
		skeleton.add_bone(bone)
	for i in range(1,8): skeleton.set_bone_parent(i,0)
	part(self,Vector3(0,1.22,0),Vector3(0.24,0.63,0),shirt)
	part(self,Vector3(0,1.72,0),Vector3(0.145,0.31,0),skin)
	part(self,Vector3(0,1.85,0.015),Vector3(0.15,0.18,0),Color(0.09,0.065,0.04))
	for i in range(4):
		var pivot := Node3D.new()
		pivot.position = Vector3((-1 if i%2==0 else 1)*(0.29 if i<2 else 0.13),1.43 if i<2 else 0.94,0)
		add_child(pivot)
		limbs.append(pivot)
		part(pivot,Vector3(0,-0.31 if i<2 else -0.49,0),Vector3(0.075 if i<2 else 0.10,0.66 if i<2 else 0.9,0),skin if i<2 else Color(0.17,0.19,0.18))

func animate(delta: float,speed: float,grounded: bool,vertical: float) -> void:
	blend = lerpf(blend,clampf(speed/6.0,0,1),1.0-exp(-delta*9))
	phase += delta*(6.0+speed)
	animation_state = "run" if speed>4.5 else ("walk" if speed>0.2 else "idle")
	if not grounded: animation_state = "jump" if vertical>0 else "fall"
	for i in limbs.size():
		var target := sin(phase+PI*(i%2))*blend*0.65
		if not grounded: target = -0.35 if i<2 else 0.2
		limbs[i].rotation.x = lerpf(limbs[i].rotation.x,target,1.0-exp(-delta*12))
