class_name InventoryModel
extends RefCounted
signal changed
const CAPACITY := 24
var definitions: Dictionary=JSON.parse_string(FileAccess.get_file_as_string("res://data/items.json"))
var slots: Array = []
var selected := 0
var health := 75
var active_tool := ""
func _init() -> void:
	for i in CAPACITY: slots.append({})
func seed_starter() -> void:
	for pair in [["axe",1],["pick",1],["berries",12],["water",5],["wood",24],["stone",10],["pack_tan",1],["hoodie_cream",1],["watch",1],["journal",1],["shell",3]]:
		add(pair[0],pair[1])
func index_valid(index: int) -> bool: return index>=0 and index<CAPACITY
func add(id: String,count: int) -> int:
	if not definitions.has(id) or count<=0: return count
	var remaining:=count
	for i in CAPACITY:
		if not slots[i].is_empty() and slots[i].id==id:
			var n:=mini(remaining,int(definitions[id].max_stack)-int(slots[i].quantity))
			slots[i].quantity+=n
			remaining-=n
	for i in CAPACITY:
		if remaining<=0: break
		if slots[i].is_empty():
			var n:=mini(remaining,int(definitions[id].max_stack))
			slots[i]={"id":id,"quantity":n}
			remaining-=n
	changed.emit()
	return remaining
func move(from: int,to: int) -> bool:
	if not index_valid(from) or not index_valid(to) or from==to or slots[from].is_empty(): return false
	if not slots[to].is_empty() and slots[to].id==slots[from].id:
		var n:=mini(int(slots[from].quantity),int(definitions[slots[to].id].max_stack)-int(slots[to].quantity))
		if n==0: return false
		slots[to].quantity+=n
		slots[from].quantity-=n
		if slots[from].quantity==0: slots[from]={}
	else:
		var old: Dictionary=slots[to]
		slots[to]=slots[from]
		slots[from]=old
	changed.emit()
	return true
func split(index: int) -> bool:
	if not index_valid(index) or slots[index].is_empty() or slots[index].quantity<2: return false
	for i in CAPACITY:
		if slots[i].is_empty():
			var n:=int(slots[index].quantity)/2
			slots[i]={"id":slots[index].id,"quantity":int(n)}
			slots[index].quantity-=int(n)
			changed.emit()
			return true
	return false
func drop(index: int,count: int=1) -> Dictionary:
	if not index_valid(index) or slots[index].is_empty() or count<=0: return {}
	if not definitions[slots[index].id].drop or count>int(slots[index].quantity): return {}
	var item: Dictionary={"id":slots[index].id,"quantity":count}
	slots[index].quantity-=count
	if slots[index].quantity==0: slots[index]={}
	if not active_tool.is_empty() and not has_item(active_tool): active_tool=""
	changed.emit()
	return item
func use(index: int) -> Dictionary:
	if not index_valid(index) or slots[index].is_empty(): return {}
	var id: String=slots[index].id
	var definition: Dictionary=definitions[id]
	if definition.has("heal"):
		health=mini(100,health+int(definition.heal))
		slots[index].quantity-=1
		if slots[index].quantity==0: slots[index]={}
		changed.emit()
		return {"message":"Used "+str(definition.name),"heal":definition.heal}
	if definition.has("tool"):
		active_tool=id
		changed.emit()
		return {"message":"Equipped "+str(definition.name),"tool":id}
	if definition.has("outfit"): return {"message":"Equipped "+str(definition.name),"outfit":definition.outfit}
	return {"message":definition.description}
func snapshot() -> Dictionary:
	return {"slots":slots.duplicate(true),"selected":selected,"health":health,"tool":active_tool}
func restore(data: Dictionary) -> bool:
	if not data.get("slots") is Array or data.slots.size()!=CAPACITY: return false
	for item in data.slots:
		if not item is Dictionary: return false
		if item.is_empty(): continue
		if not definitions.has(item.get("id","")): return false
		var q: float=float(item.get("quantity",0))
		if q!=floor(q) or q<1 or q>definitions[item.id].max_stack: return false
	if not data.get("selected",0) is float and not data.get("selected",0) is int: return false
	var choice:=int(data.get("selected",0))
	if choice<0 or choice>5: return false
	var hp:=int(data.get("health",100))
	if hp<0 or hp>100: return false
	var tool: String=data.get("tool","")
	if tool not in ["","axe","pick"]: return false
	slots=data.slots.duplicate(true)
	selected=choice
	health=hp
	active_tool=tool
	changed.emit()
	return true

func has_item(id: String) -> bool:
	for item in slots:
		if item.get("id","")==id: return true
	return false
