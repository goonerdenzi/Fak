class_name IslandVegetation
extends RefCounted
static func bark() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.24,0.22,0.16)
	m.roughness = 0.95
	return m
static func palm_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	# Tapered curved trunk, with ring ridges rather than a cylinder primitive.
	for j in range(16):
		for k in range(9):
			var pts: Array[Vector3] = []
			for q in [Vector2(k,j),Vector2(k+1,j),Vector2(k,j+1),Vector2(k+1,j+1)]:
				var y: float = q.y*0.6
				var r: float = (0.22-q.y*0.006)*(1.0+0.08*sin(q.y*3.0))
				pts.append(Vector3(cos(q.x*TAU/9.0)*r+y*y*0.012,y,sin(q.x*TAU/9.0)*r))
			for i in [0,2,1,1,2,3]: st.add_vertex(pts[i])
	st.generate_normals()
	st.set_material(bark())
	var mesh := st.commit()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for f in range(11):
		var angle := f*2.399
		var dir := Vector3(cos(angle),0,sin(angle))
		var side := Vector3(-sin(angle),0,cos(angle))
		for j in range(14):
			var t := float(j)/14.0
			var t2 := float(j+1)/14.0
			var p := Vector3(1.1,9.5,0)+dir*t*4.8+Vector3.UP*(sin(t*PI)*1.4-t*t*1.7)
			var p2 := Vector3(1.1,9.5,0)+dir*t2*4.8+Vector3.UP*(sin(t2*PI)*1.4-t2*t2*1.7)
			# Individual tapered leaflets give the crown a feathered silhouette.
			for sign_value in [-1.0,1.0]:
				var tip: Vector3 = p+side*sign_value*sin(t*PI)*1.0-dir*0.4+Vector3.DOWN*0.25
				for seg in range(4):
					var a := float(seg)/4.0
					var b := float(seg+1)/4.0
					var middle := p.lerp(tip,a)
					var next := p.lerp(tip,b)
					var w := sin(a*PI)*0.11
					var w2 := sin(b*PI)*0.11
					var pts := [middle-dir*w,middle+dir*w,next-dir*w2,next+dir*w2]
					for idx in [0,2,1,1,2,3]:
						st.set_uv(Vector2(float(idx%2),a if idx<2 else b))
						st.add_vertex(pts[idx])
	st.generate_normals()
	var leaf := ShaderMaterial.new()
	leaf.shader = load("res://shaders/leaves.gdshader")
	st.set_material(leaf)
	return st.commit(mesh)

static func jungle_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var rng := RandomNumberGenerator.new()
	rng.seed=7281
	var tips: Array[Vector3] = []
	for branch in range(13):
		var start := Vector3.ZERO if branch==0 else Vector3(0,4.0+float(branch%3),0)
		var angle := float(branch)*2.399
		var end := Vector3(0,9,0) if branch==0 else Vector3(cos(angle)*3.6,8.0+float(branch%4)*0.7,sin(angle)*3.6)
		tips.append(end)
		var axis := (end-start).normalized()
		var side := axis.cross(Vector3.FORWARD).normalized()
		var other := axis.cross(side).normalized()
		for j in range(7):
			for k in range(7):
				var pts: Array[Vector3] = []
				for q in [Vector2(k,j),Vector2(k+1,j),Vector2(k,j+1),Vector2(k+1,j+1)]:
					var t: float = q.y/7.0
					var radius: float = lerpf(0.32 if branch==0 else 0.13,0.035,t)
					pts.append(start.lerp(end,t)+(side*cos(q.x*TAU/7.0)+other*sin(q.x*TAU/7.0))*radius)
				for idx in [0,2,1,1,2,3]: st.add_vertex(pts[idx])
	st.generate_normals()
	st.set_material(bark())
	var mesh := st.commit()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for tip in tips:
		for leaf_index in range(50):
			var center := tip+Vector3(rng.randf_range(-1.6,1.6),rng.randf_range(-0.6,1.1),rng.randf_range(-1.6,1.6))
			var angle := rng.randf()*TAU
			var direction := Vector3(cos(angle),rng.randf_range(-0.5,0.6),sin(angle))*rng.randf_range(0.6,1.2)
			var side := Vector3(-sin(angle),0,cos(angle))
			for segment in range(3):
				var a := float(segment)/3.0
				var b := float(segment+1)/3.0
				var p := center+direction*a+Vector3.UP*sin(a*PI)*0.15
				var q := center+direction*b+Vector3.UP*sin(b*PI)*0.15
				var pts := [p-side*sin(a*PI)*0.27,p+side*sin(a*PI)*0.27,q-side*sin(b*PI)*0.27,q+side*sin(b*PI)*0.27]
				for idx in [0,2,1,1,2,3]:
					st.set_uv(Vector2(float(idx%2),a if idx<2 else b))
					st.add_vertex(pts[idx])
	st.generate_normals()
	var leaf := ShaderMaterial.new()
	leaf.shader = load("res://shaders/leaves.gdshader")
	leaf.set_shader_parameter("tint",Color(0.12,0.22,0.075))
	st.set_material(leaf)
	return st.commit(mesh)

static func rock_mesh() -> ArrayMesh:
	var source := SphereMesh.new()
	source.radial_segments = 9
	source.rings = 5
	var arrays := source.get_mesh_arrays()
	var vertices: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	for i in vertices.size():
		var v := vertices[i]
		var rough := 1.0+sin(v.x*19+v.z*8)*0.14+cos(v.y*23)*0.1
		vertices[i] = v*Vector3(2.7,1.4,2.2)*rough
	arrays[Mesh.ARRAY_VERTEX] = vertices
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES,arrays)
	var mat := ShaderMaterial.new()
	mat.shader = load("res://shaders/terrain.gdshader")
	mesh.surface_set_material(0,mat)
	return mesh

static func understory_mesh() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for leaf in range(15):
		var a := float(leaf)*2.399
		var d := Vector3(cos(a),0,sin(a))
		var side := Vector3(-sin(a),0,cos(a))
		for j in range(4):
			var t := float(j)/4
			var u := float(j+1)/4
			var p := d*t*0.8+Vector3.UP*sin(t*PI*0.8)*0.65
			var q := d*u*0.8+Vector3.UP*sin(u*PI*0.8)*0.65
			var pts := [p-side*sin(t*PI)*0.13,p+side*sin(t*PI)*0.13,q-side*sin(u*PI)*0.13,q+side*sin(u*PI)*0.13]
			for k in [0,2,1,1,2,3]:
				st.set_uv(Vector2(k%2,t if k<2 else u))
				st.add_vertex(pts[k])
	st.generate_normals()
	var material := ShaderMaterial.new()
	material.shader=load("res://shaders/leaves.gdshader")
	material.set_shader_parameter("tint",Color(0.26,0.40,0.09))
	st.set_material(material)
	return st.commit()

static func meadow_mesh() -> ArrayMesh:
	var st:=SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for blade in range(16):
		var a:=float(blade)*2.399
		var side:=Vector3(cos(a),0,sin(a))
		var base:=side*float(blade%4)*0.07
		var height:=0.36+float(blade%5)*0.08
		for j in range(3):
			var t:=float(j)/3.0
			var u:=float(j+1)/3.0
			var p:=base+Vector3.UP*t*height+side*t*t*0.2
			var q:=base+Vector3.UP*u*height+side*u*u*0.2
			var points: Array[Vector3]=[p-side*(1-t)*0.035,p+side*(1-t)*0.035,q-side*(1-u)*0.035,q+side*(1-u)*0.035]
			for k in [0,2,1,1,2,3]:
				st.set_uv(Vector2(k%2,t if k<2 else u))
				st.add_vertex(points[k])
	st.generate_normals()
	var leaves:=ShaderMaterial.new()
	leaves.shader=load("res://shaders/leaves.gdshader")
	leaves.set_shader_parameter("tint",Color(0.32,0.42,0.12))
	st.set_material(leaves)
	var mesh:=st.commit()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for flower in range(3):
		var center:=Vector3(float(flower-1)*0.18,0.45+float(flower%2)*0.13,0.08)
		for petal in range(5):
			var a:=float(petal)*TAU/5
			var d:=Vector3(cos(a),0,sin(a))*0.1
			var s:=Vector3(-sin(a),0,cos(a))*0.045
			st.set_color(Color("edca6c") if flower%2==0 else Color("d87969"))
			for p in [center,center+d+s,center+d*1.35,center,center+d*1.35,center+d-s]: st.add_vertex(p)
	st.generate_normals()
	var petals:=StandardMaterial3D.new()
	petals.vertex_color_use_as_albedo=true
	petals.cull_mode=BaseMaterial3D.CULL_DISABLED
	petals.roughness=0.9
	st.set_material(petals)
	return st.commit(mesh)
