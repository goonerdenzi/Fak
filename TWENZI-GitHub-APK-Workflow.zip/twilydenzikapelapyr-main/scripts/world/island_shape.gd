class_name IslandShape
extends RefCounted
const RADIUS := 2300.0
static var noise: FastNoiseLite
static func init_noise() -> void:
	if noise != null: return
	noise = FastNoiseLite.new()
	noise.seed = 27112024
	noise.frequency = 0.0035
	noise.fractal_octaves = 5
static func river_x(z: float) -> float:
	return 90.0 + sin(z * 0.006) * 100.0
static func height(x: float, z: float) -> float:
	var original := original_height(x,z)
	if x<620.0: return original
	var d := Vector2((x-1390.0)*0.92,z+80.0).length()
	var edge := 820.0+sin(atan2(z+80.0,x-1390.0)*4.0)*60.0
	var h := (edge-d)*0.065
	if h>0:
		var inland := smoothstep(0.0,250.0,edge-d)
		h+=inland*(110.0*exp(-pow((x-1550.0)/310.0,2.0)-pow((z+290.0)/360.0,2.0))+noise.get_noise_2d(x,z)*26.0)
	return maxf(original,lerpf(original,h,smoothstep(620.0,820.0,x)))
static func original_height(x: float, z: float) -> float:
	init_noise()
	var r := Vector2(x / 1.04, z).length()
	var coast := 855.0 + noise.get_noise_2d(x * 0.4, z * 0.4) * 170.0 + sin(atan2(z,x)*5.0)*35.0
	var inland := clampf((coast-r)/310.0,0.0,1.0)
	var h := (coast-r)*0.065
	if r > coast: return maxf(-35.0,h)
	var peaks := exp(-pow((x+210.0)/280.0,2.0)-pow((z+200.0)/370.0,2.0))*180.0
	h += inland*(peaks+noise.get_noise_2d(x,z)*60.0+noise.get_noise_2d(x*3.0,z*3.0)*8.0)
	# A continuous river valley drops from the upland lake to the east estuary.
	if z > -440.0 and z < 770.0:
		var d := absf(x-river_x(z))
		var bed := maxf(-1.8,(-z+360.0)*0.035)
		h = lerpf(h,bed-2.0,1.0-smoothstep(9.0,42.0,d))
	var lake := Vector2(x-8.0,z+380.0).length()
	if lake < 85.0:
		h = lerpf(24.0,29.0,smoothstep(55.0,85.0,lake))
	elif lake < 200.0:
		h = lerpf(29.0,h,smoothstep(85.0,200.0,lake))
	return h
static func normal(x: float,z: float) -> Vector3:
	return Vector3(height(x-1,z)-height(x+1,z),2.0,height(x,z-1)-height(x,z+1)).normalized()
