extends Node3D
const CHUNK := 96.0
var chunks: Dictionary = {}
var distant: Dictionary = {}
var pinned_keys: Dictionary = {}
var queue: Array[Vector2i] = []
var focus: Node3D
var terrain_material: ShaderMaterial
var palm: ArrayMesh
var jungle: ArrayMesh
var rock: ArrayMesh
var regions: Array
var markers: Array[Node3D] = []
var current_center := Vector2i(9999,9999)
var sun: DirectionalLight3D
var ocean: MeshInstance3D
var last_radius := 0
var ground_cover: ArrayMesh
var meadow: ArrayMesh
var sky_material: ShaderMaterial
var world_minutes := 624.0
var sunset := false
var prune_elapsed := 0.0

func _ready() -> void:
	terrain_material = ShaderMaterial.new()
	terrain_material.shader = load("res://shaders/terrain.gdshader")
	palm = IslandVegetation.palm_mesh()
	jungle = IslandVegetation.jungle_mesh()
	rock = IslandVegetation.rock_mesh()
	ground_cover = IslandVegetation.understory_mesh()
	meadow = IslandVegetation.meadow_mesh()
	regions = JSON.parse_string(FileAccess.get_file_as_string("res://data/regions.json"))
	create_environment()
	create_distant_terrain()
	create_landmarks()
	get_viewport().use_occlusion_culling=true
	for peak in [Vector3(-210,50,-200),Vector3(1550,40,-290)]:
		var occluder:=OccluderInstance3D.new()
		var box:=BoxOccluder3D.new()
		box.size=Vector3(70,peak.y*2.0,70)
		occluder.occluder=box
		occluder.position=peak
		add_child(occluder)
	Preferences.changed.connect(update_quality)
	update_quality()

func update_quality() -> void:
	sun.shadow_enabled = Preferences.shadows
	terrain_material.set_shader_parameter("detail",float(Preferences.texture_quality))
	for node in chunks.values(): node.queue_free()
	for node in distant.values(): node.show()
	chunks.clear()
	queue.clear()
	current_center = Vector2i(9999,9999)

func create_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.19,0.34,0.46)
	sky_mat.sky_horizon_color = Color(0.65,0.71,0.69)
	sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
	sky_mat.ground_bottom_color = Color(0.15,0.20,0.18)
	sky_material = ShaderMaterial.new()
	sky_material.shader = load("res://shaders/island_sky.gdshader")
	sky.sky_material = sky_material
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.4
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_sky_affect=0.12
	env.fog_light_color = Color(0.52,0.72,0.83)
	env.fog_density = 0.00045
	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48,-38,0)
	sun.light_color = Color(1.0,0.96,0.85)
	sun.light_energy = 0.95
	sun.directional_shadow_max_distance = 100.0
	add_child(sun)
	ocean = MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(6500,6500)
	plane.subdivide_width = 128
	plane.subdivide_depth = 128
	ocean.mesh = plane
	var water := ShaderMaterial.new()
	water.shader = load("res://shaders/water.gdshader")
	var heights := Image.create(256,256,false,Image.FORMAT_RF)
	for x in 256:
		for z in 256:
			heights.set_pixel(x,z,Color(IslandShape.height(-1200+x/255.0*3800,-1400+z/255.0*2800),0,0))
	water.set_shader_parameter("height_map",ImageTexture.create_from_image(heights))
	ocean.material_override = water
	add_child(ocean)
	# Continuous river surface, following the carved valley.
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for z in range(-440,770,8):
		var points: Array[Vector3] = []
		for p in [Vector2(-8,z),Vector2(8,z),Vector2(-8,z+8),Vector2(8,z+8)]:
			points.append(Vector3(IslandShape.river_x(p.y)+p.x,maxf(0.1,(-p.y+360.0)*0.035),p.y))
		for idx in [0,1,2,1,3,2]: st.add_vertex(points[idx])
	st.generate_normals()
	var river := MeshInstance3D.new()
	river.mesh = st.commit()
	river.material_override = water
	add_child(river)
	var lake := MeshInstance3D.new()
	var disc := CylinderMesh.new()
	disc.top_radius = 72.0
	disc.bottom_radius = 72.0
	disc.height = 0.1
	disc.radial_segments = 64
	lake.mesh = disc
	lake.position = Vector3(8,26,-380)
	lake.material_override = water
	add_child(lake)

func _process(_delta: float) -> void:
	world_minutes = fmod(world_minutes+_delta*0.3,1440.0)
	if not is_instance_valid(focus): return
	var center := Vector2i(floori(focus.position.x/CHUNK),floori(focus.position.z/CHUNK))
	var radius: int = Preferences.view_distance
	if center != current_center or radius != last_radius:
		current_center = center
		last_radius = radius
		queue.clear()
		for x in range(-radius,radius+1):
			for z in range(-radius,radius+1):
				var key := center+Vector2i(x,z)
				if not chunks.has(key): queue.append(key)
		queue.sort_custom(func(a:Vector2i,b:Vector2i): return a.distance_squared_to(center)<b.distance_squared_to(center))
		for key in chunks.keys():
			if maxi(absi(key.x-center.x),absi(key.y-center.y))>radius+1 and not pinned_keys.has(key):
				chunks[key].queue_free()
				chunks.erase(key)
				if distant.has(key): distant[key].show()
	prune_elapsed+=_delta
	if prune_elapsed>1.0:
		prune_elapsed=0.0
		for key in chunks.keys():
			if maxi(absi(key.x-center.x),absi(key.y-center.y))>radius+1 and not pinned_keys.has(key):
				chunks[key].queue_free()
				chunks.erase(key)
				if distant.has(key): distant[key].show()
	# At most one terrain allocation per frame; collision arrives nearest-first.
	if not queue.is_empty(): build_chunk(queue.pop_front())

func ensure_ground(pos: Vector3) -> void:
	var c := Vector2i(floori(pos.x/CHUNK),floori(pos.z/CHUNK))
	for x in range(-1,2):
		for z in range(-1,2):
			if not chunks.has(c+Vector2i(x,z)): build_chunk(c+Vector2i(x,z))

func build_chunk(key: Vector2i) -> void:
	if chunks.has(key): return
	var root := Node3D.new()
	root.position = Vector3(key.x*CHUNK,0,key.y*CHUNK)
	add_child(root)
	chunks[key] = root
	if distant.has(key): distant[key].hide()
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	const STEP := 6
	for x in range(0,96,STEP):
		for z in range(0,96,STEP):
			for p in [Vector2(x,z),Vector2(x+STEP,z),Vector2(x,z+STEP),Vector2(x+STEP,z),Vector2(x+STEP,z+STEP),Vector2(x,z+STEP)]:
				var wx: float = root.position.x+p.x
				var wz: float = root.position.z+p.y
				st.set_normal(IslandShape.normal(wx,wz))
				st.set_uv(Vector2(wx,wz)*0.1)
				st.add_vertex(Vector3(p.x,IslandShape.height(wx,wz),p.y))
	var terrain := MeshInstance3D.new()
	terrain.mesh = st.commit()
	terrain.material_override = terrain_material
	root.add_child(terrain)
	terrain.create_trimesh_collision()
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(key)*127
	var transforms: Array[Transform3D] = []
	var broad: Array[Transform3D] = []
	for i in range(int(72*Preferences.vegetation)):
		var x := rng.randf_range(0,CHUNK)
		var z := rng.randf_range(0,CHUNK)
		var wx := root.position.x+x
		var wz := root.position.z+z
		var h := IslandShape.height(wx,wz)
		if h<2.5 or h>125 or IslandShape.normal(wx,wz).y<0.85: continue
		if Vector2(wx-8.0,wz+380.0).length()<75.0: continue
		if absf(wx-IslandShape.river_x(wz))<15.0: continue
		var clear := false
		for r in regions:
			if Vector2(wx-r.x,wz-r.z).length()<15.0: clear = true
		if clear: continue
		var scale_value := rng.randf_range(0.7,1.5)
		var t := Transform3D(Basis(Vector3.UP,rng.randf()*TAU).scaled(Vector3.ONE*scale_value),Vector3(x,h,z))
		if h<15.0 or i%3==0: transforms.append(t)
		else: broad.append(t)
	add_instances(root,palm,transforms)
	add_instances(root,jungle,broad)
	var stones: Array[Transform3D] = []
	for i in range(14):
		var x := rng.randf_range(0,CHUNK)
		var z := rng.randf_range(0,CHUNK)
		var h := IslandShape.height(root.position.x+x,root.position.z+z)
		if h<0.5: continue
		if Vector2(root.position.x+x-8.0,root.position.z+z+380.0).length()<75.0: continue
		var scale_value := rng.randf_range(0.4,2.8)
		stones.append(Transform3D(Basis(Vector3.UP,rng.randf()*TAU).scaled(Vector3.ONE*scale_value),Vector3(x,h,z)))
	add_instances(root,rock,stones)
	var plants: Array[Transform3D] = []
	var flowers: Array[Transform3D] = []
	for i in int(190*Preferences.vegetation):
		var x := rng.randf_range(0,CHUNK)
		var z := rng.randf_range(0,CHUNK)
		var wx := root.position.x+x
		var wz := root.position.z+z
		var h := IslandShape.height(wx,wz)
		if h<4 or h>160 or Vector2(wx-8,wz+380).length()<76: continue
		if wz>-440 and wz<770 and absf(wx-IslandShape.river_x(wz))<15: continue
		var scale_value := rng.randf_range(0.45,1.3)
		var transform:=Transform3D(Basis(Vector3.UP,rng.randf()*TAU).scaled(Vector3.ONE*scale_value),Vector3(x,h,z))
		if i%3==0: flowers.append(transform)
		else: plants.append(transform)
	var cover := add_instances(root,ground_cover,plants)
	cover.visibility_range_end=95.0
	var field:=add_instances(root,meadow,flowers)
	field.visibility_range_end=80.0

func add_instances(root: Node3D,mesh: Mesh,transforms: Array[Transform3D]) -> MultiMeshInstance3D:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = transforms.size()
	for i in transforms.size(): mm.set_instance_transform(i,transforms[i])
	var instance := MultiMeshInstance3D.new()
	instance.multimesh = mm
	instance.visibility_range_end = 290.0
	root.add_child(instance)
	return instance

func solid(parent: Node3D,pos: Vector3,size: Vector3,color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	m.mesh = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	m.material_override = mat
	m.position = pos
	parent.add_child(m)
	m.create_trimesh_collision()
	return m

func create_landmarks() -> void:
	for r in regions:
		var marker := Node3D.new()
		marker.position = Vector3(r.x,IslandShape.height(r.x,r.z),r.z)
		marker.set_meta("title",r.name)
		marker.set_meta("description",r.description)
		add_child(marker)
		markers.append(marker)
		var stone := Color(0.32,0.31,0.26)
		if r.kind == "ruins":
			for i in range(6):
				solid(marker,Vector3(i*2-5,1.3,-4),Vector3(1.8,2.6,0.8),stone)
			for i in range(3): solid(marker,Vector3(-5,0.8,i*2),Vector3(0.8,1.6,1.8),stone)
		elif r.kind == "cave":
			for i in range(7):
				var a := float(i)/6.0*PI
				var rock := solid(marker,Vector3(cos(a)*4, sin(a)*4,-3),Vector3(2.2,2.4,7),stone)
				rock.rotation.z = a-PI*0.5
		elif r.kind == "camp" or r.kind == "jungle":
			for i in range(8):
				var a := float(i)*TAU/8
				solid(marker,Vector3(cos(a),0.15,sin(a)),Vector3(0.4,0.3,0.4),stone)
			solid(marker,Vector3(-3,0.45,-2),Vector3(2.5,0.5,0.4),Color(0.21,0.14,0.08))
		elif r.kind == "lookout":
			var beacon:=MeshInstance3D.new()
			var tower:=CylinderMesh.new()
			tower.bottom_radius=2.4
			tower.top_radius=1.6
			tower.height=14.0
			beacon.mesh=tower
			beacon.position.y=7.0
			beacon.material_override=terrain_material
			marker.add_child(beacon)
			beacon.create_trimesh_collision()
			solid(marker,Vector3(0,15,0),Vector3(3.7,0.6,3.7),Color("a06a42"))
		elif r.kind == "falls":
			for i in range(4):
				solid(marker,Vector3(-4,float(i)*1.2,-float(i)*3),Vector3(9,1.0,3),stone)
				var sheet := solid(marker,Vector3(-4,float(i)*1.2+0.6,-float(i)*3+1.4),Vector3(8,1.4,0.12),Color(0.49,0.69,0.67))
				var flowing := ShaderMaterial.new()
				flowing.shader=load("res://shaders/falls.gdshader")
				sheet.material_override = flowing
		else:
			solid(marker,Vector3(0,0.6,0),Vector3(0.8,1.2,0.7),stone)

func create_distant_terrain() -> void:
	# Coarse horizon tiles remain visible outside the collision streaming radius.
	for cx in range(-12,26):
		for cz in range(-15,15):
			var key := Vector2i(cx,cz)
			var st := SurfaceTool.new()
			st.begin(Mesh.PRIMITIVE_TRIANGLES)
			for x in range(0,96,24):
				for z in range(0,96,24):
					for p in [Vector2(x,z),Vector2(x+24,z),Vector2(x,z+24),Vector2(x+24,z),Vector2(x+24,z+24),Vector2(x,z+24)]:
						var wx: float = cx*CHUNK+p.x
						var wz: float = cz*CHUNK+p.y
						st.set_normal(IslandShape.normal(wx,wz))
						st.add_vertex(Vector3(wx,IslandShape.height(wx,wz)-0.15,wz))
			var tile := MeshInstance3D.new()
			tile.mesh = st.commit()
			tile.material_override = terrain_material
			tile.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(tile)
			distant[key] = tile

func set_sunset(enabled: bool) -> void:
	sunset=enabled
	sky_material.set_shader_parameter("sunset",1.0 if enabled else 0.0)
	sun.rotation_degrees.x=-16 if enabled else -48
	sun.light_color=Color(1.0,0.65,0.36) if enabled else Color(1.0,0.96,0.85)
	world_minutes=1080.0 if enabled else 624.0
