extends Node
signal roster_changed
signal status_changed(text: String)
var app: Node
var active := false
var joined := false
var room_code := ""
var display_name := ""
var actors: Dictionary = {}
var records: Dictionary = {}
var inventories: Dictionary = {}
var drops: Dictionary = {}
var drop_nodes: Dictionary = {}
var last_input: Dictionary = {}
var pending: Dictionary = {}
var last_action: Dictionary = {}
var offline_inventory: Dictionary = {}
var state_timer := 0.0
var next_drop := 1
var requested_code := ""
var last_status := "Offline"
const PROTOCOL := 2
func _ready() -> void:
	process_mode=Node.PROCESS_MODE_ALWAYS
	# All game RPCs go through the host; disable unused peer-to-peer relay notifications.
	multiplayer.server_relay=false
	multiplayer.peer_connected.connect(peer_connected)
	multiplayer.peer_disconnected.connect(peer_disconnected)
	multiplayer.connected_to_server.connect(connected)
	multiplayer.connection_failed.connect(func(): message("Connection failed"); leave())
	multiplayer.server_disconnected.connect(func(): message("Host disconnected"); leave())
func message(value: String) -> void:
	last_status=value
	status_changed.emit(value)
	if is_instance_valid(app) and is_instance_valid(app.toast): app.toast.text=value
func begin() -> void:
	offline_inventory=Profile.inventory.snapshot()
	Profile.offline_inventory=offline_inventory.duplicate(true)
	Profile.network_session=true
	active=true
func host(port: int,username: String,code_override: String="") -> Error:
	if active: return ERR_ALREADY_IN_USE
	var peer:=ENetMultiplayerPeer.new()
	var err:=peer.create_server(port,3)
	if err!=OK: return err
	multiplayer.multiplayer_peer=peer
	begin()
	joined=true
	room_code=Crypto.new().generate_random_bytes(4).hex_encode().to_upper() if code_override.is_empty() else code_override
	display_name=username.strip_edges().left(24)
	actors[1]=app.player
	app.player.network_id=1
	app.player.display_name=display_name
	records[1]={"name":display_name,"character":Profile.character,"outfit":Profile.outfit()}
	inventories[1]=Profile.inventory
	message("Hosting on UDP %d · Room %s"%[port,room_code])
	return OK
func join(address: String,port: int,code: String,username: String) -> Error:
	if active: return ERR_ALREADY_IN_USE
	var peer:=ENetMultiplayerPeer.new()
	var err:=peer.create_client(address,port)
	if err!=OK: message(error_string(err)); return err
	multiplayer.multiplayer_peer=peer
	requested_code=code
	display_name=username.strip_edges().left(24)
	begin()
	app.player.input_locked=true
	message("Connecting…")
	return OK
func leave() -> void:
	if not active: return
	active=false
	joined=false
	if multiplayer.multiplayer_peer: multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer=OfflineMultiplayerPeer.new()
	for actor in actors.values():
		if is_instance_valid(actor) and actor!=app.player: actor.queue_free()
	for node in drop_nodes.values():
		if is_instance_valid(node): node.queue_free()
	actors.clear(); records.clear(); inventories.clear(); drops.clear(); drop_nodes.clear()
	last_input.clear(); pending.clear(); last_action.clear()
	if is_instance_valid(app.player):
		app.player.remote_controlled=false
		app.player.network_id=0
		app.player.input_locked=false
	Profile.inventory.restore(offline_inventory)
	Profile.network_session=false
	Profile.save_profile()
	if is_instance_valid(app.island): app.island.pinned_keys.clear()
	roster_changed.emit()
func connected() -> void:
	join_request.rpc_id(1,PROTOCOL,requested_code,display_name,Profile.character,Profile.outfit())
func peer_connected(id: int) -> void:
	if multiplayer.is_server(): pending[id]=Time.get_ticks_msec()
func peer_disconnected(id: int) -> void:
	pending.erase(id)
	if actors.has(id):
		actors[id].queue_free()
		actors.erase(id)
	records.erase(id); inventories.erase(id); last_input.erase(id)
	if active and multiplayer.is_server(): publish_roster.call_deferred()
	roster_changed.emit()
@rpc("any_peer","call_remote","reliable")
func join_request(version: int,code: String,username: String,character: String,initial_outfit: Dictionary) -> void:
	if not active or not multiplayer.is_server(): return
	var id:=multiplayer.get_remote_sender_id()
	if not pending.has(id): return
	if version!=PROTOCOL or code!=room_code or records.size()>=4 or character not in ["Twily","Denzi"] or not ClothingCatalog.valid(initial_outfit):
		join_denied.rpc_id(id,"Room code, protocol or capacity rejected")
		pending.erase(id)
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	pending.erase(id)
	var config:=initial_outfit.duplicate(true)
	records[id]={"name":username.strip_edges().left(24),"character":character,"outfit":config}
	inventories[id]=InventoryModel.new()
	inventories[id].seed_starter()
	spawn_actor(id,records[id])
	last_input[id]=Time.get_ticks_msec()
	publish_roster()
	inventory_snapshot.rpc_id(id,inventories[id].snapshot())
	drop_snapshot.rpc_id(id,drops)
	message("Player joined · %d / 4"%records.size())
@rpc("authority","call_remote","reliable")
func join_denied(reason: String) -> void:
	message(reason)
	leave()
func spawn_actor(id: int,record: Dictionary) -> void:
	var actor=load("res://scenes/characters/%s.tscn"%str(record.character).to_lower()).instantiate()
	actor.remote_controlled=true
	actor.network_id=id
	actor.display_name=record.name
	var p:=Vector3(-120+(id%4)*2.5,0,750+(id%3)*2.0)
	p.y=IslandShape.height(p.x,p.z)+0.6
	app.island.ensure_ground(p)
	actor.position=p
	app.island.add_child(actor)
	actor.visual.apply_outfit(record.outfit)
	var tag:=Label3D.new()
	tag.text=record.name
	tag.position.y=2.1
	tag.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	tag.font_size=32
	actor.add_child(tag)
	actors[id]=actor
func connected_ids() -> Array[int]:
	var ids: Array[int]=[]
	if not active or not multiplayer.multiplayer_peer is ENetMultiplayerPeer: return ids
	for id in records:
		if id==1 or id not in multiplayer.get_peers(): continue
		var peer: ENetPacketPeer=multiplayer.multiplayer_peer.get_peer(id)
		if peer and peer.get_state()==ENetPacketPeer.STATE_CONNECTED: ids.append(id)
	return ids
func publish_roster() -> void:
	if not active or not multiplayer.is_server(): return
	for id in connected_ids(): roster.rpc_id(id,records,room_code)
	roster_changed.emit()
@rpc("authority","call_remote","reliable")
func roster(data: Dictionary,code: String) -> void:
	if not active: return
	records=data
	room_code=code
	var local_id:=multiplayer.get_unique_id()
	for id in actors.keys():
		if not data.has(id):
			if actors[id]!=app.player: actors[id].queue_free()
			actors.erase(id)
	for id in data:
		if id==local_id:
			actors[id]=app.player
			app.player.network_id=id
			app.player.display_name=data[id].name
			app.player.input_locked=false
			Profile.outfits[Profile.character]=data[id].outfit.duplicate(true)
			if is_instance_valid(app.portrait): app.portrait.model.apply_outfit(data[id].outfit)
			if is_instance_valid(app.preview_model): app.preview_model.model.apply_outfit(data[id].outfit)
		elif not actors.has(id): spawn_actor(id,data[id])
		actors[id].visual.apply_outfit(data[id].outfit)
	joined=data.has(local_id)
	message("Connected · %d / 4 players"%data.size())
	roster_changed.emit()
func submit_local(command: Dictionary,yaw: float) -> void:
	if not active or not joined or multiplayer.is_server(): return
	request_move.rpc_id(1,command.move,command.run,yaw)
	if command.jump: request_jump.rpc_id(1)
@rpc("any_peer","call_remote","unreliable_ordered",1)
func request_move(move: Vector2,running: bool,yaw: float) -> void:
	if not active or not multiplayer.is_server(): return
	var id:=multiplayer.get_remote_sender_id()
	if not actors.has(id) or not move.is_finite() or not is_finite(yaw): return
	actors[id].net_command.move=move.limit_length()
	actors[id].net_command.run=running
	actors[id].rig.yaw=wrapf(yaw,-PI,PI)
	last_input[id]=Time.get_ticks_msec()
@rpc("any_peer","call_remote","reliable")
func request_jump() -> void:
	if not active or not multiplayer.is_server(): return
	var id:=multiplayer.get_remote_sender_id()
	if actors.has(id): actors[id].net_command.jump=true
func _physics_process(delta: float) -> void:
	if not active or not joined or not multiplayer.is_server(): return
	var now:=Time.get_ticks_msec()
	for id in pending.keys():
		if now-int(pending[id])>5000:
			pending.erase(id)
			multiplayer.multiplayer_peer.disconnect_peer(id)
	state_timer+=delta
	if state_timer<0.05: return
	state_timer=0
	app.island.pinned_keys.clear()
	var state: Dictionary={}
	for id in actors:
		var actor: CharacterBody3D=actors[id]
		if id!=1:
			if now-int(last_input.get(id,0))>300: actor.net_command.move=Vector2.ZERO; actor.net_command.run=false
			var c:=Vector2i(floori(actor.position.x/96),floori(actor.position.z/96))
			for x in range(-1,2):
				for z in range(-1,2): app.island.pinned_keys[c+Vector2i(x,z)]=true
			if not app.island.chunks.has(c): app.island.ensure_ground(actor.position)
		state[id]={"position":actor.position,"velocity":actor.velocity,"rotation":actor.visual.rotation.y,"grounded":actor.is_on_floor(),"state":actor.locomotion_state,"tool":inventories[id].active_tool}
	for id in connected_ids(): world_state.rpc_id(id,state,app.island.world_minutes)
@rpc("authority","call_remote","unreliable_ordered",2)
func world_state(state: Dictionary,time: float) -> void:
	if not active: return
	app.island.world_minutes=time
	for id in state:
		if not actors.has(id): continue
		var actor: CharacterBody3D=actors[id]
		var packet: Dictionary=state[id]
		actor.visual.equip_tool(packet.get("tool",""))
		if actor==app.player:
			var error:=actor.position.distance_to(packet.position)
			actor.position=packet.position if error>2.5 else actor.position.lerp(packet.position,0.18)
			if error>2.5:
				actor.velocity=packet.velocity
			elif packet.state=="jump" and actor.velocity.y<=0:
				# A client may predict airborne while the host still accepts a grounded jump.
				actor.velocity.y=packet.velocity.y
		else:
			actor.net_target=packet.position
			actor.velocity=packet.velocity
			actor.visual.rotation.y=packet.rotation
			actor.net_grounded=packet.grounded
			actor.locomotion_state=packet.state
func request_outfit(config: Dictionary) -> void:
	if not active: return
	if multiplayer.is_server(): apply_outfit(1,config)
	else: outfit_request.rpc_id(1,config)
@rpc("any_peer","call_remote","reliable")
func outfit_request(config: Dictionary) -> void:
	if multiplayer.is_server(): apply_outfit(multiplayer.get_remote_sender_id(),config)
func apply_outfit(id: int,config: Dictionary) -> bool:
	if not records.has(id) or not ClothingCatalog.valid(config): return false
	records[id].outfit=config.duplicate(true)
	actors[id].visual.apply_outfit(config)
	publish_roster()
	return true
func inventory_request(operation: String,index: int,to: int=-1) -> void:
	if multiplayer.is_server(): apply_inventory(1,operation,index,to)
	else: inventory_rpc.rpc_id(1,operation,index,to)
@rpc("any_peer","call_remote","reliable")
func inventory_rpc(operation: String,index: int,to: int) -> void:
	if multiplayer.is_server(): apply_inventory(multiplayer.get_remote_sender_id(),operation,index,to)
func apply_inventory(id: int,operation: String,index: int,to: int) -> void:
	if not inventories.has(id): return
	var bag: InventoryModel=inventories[id]
	if not bag.index_valid(index): return
	match operation:
		"move": bag.move(index,to)
		"split": bag.split(index)
		"select":
			if index<6:
				bag.selected=index
				var item: Dictionary=bag.slots[index]
				bag.active_tool=item.id if not item.is_empty() and bag.definitions[item.id].get("tool",false) else ""
				actors[id].visual.equip_tool(bag.active_tool)
		"drop":
			var item:=bag.drop(index)
			if not item.is_empty():
				drops[next_drop]={"item":item,"position":actors[id].position+Vector3(1,0.4,0)}
				next_drop+=1
				for recipient in connected_ids(): drop_snapshot.rpc_id(recipient,drops)
				render_drops()
		"use":
			var now:=Time.get_ticks_msec()
			if now-int(last_action.get(id,0))<500: return
			last_action[id]=now
			var result:=bag.use(index)
			if result.has("outfit"):
				var config: Dictionary=records[id].outfit.duplicate(true)
				config[ClothingCatalog.definitions()[result.outfit].slot]=result.outfit
				apply_outfit(id,config)
			if result.has("tool"): app.use_tool(actors[id],bag,result.tool)
			actors[id].visual.trigger_action()
			for recipient in connected_ids(): play_action.rpc_id(recipient,id)
	sync_inventory(id)
func sync_inventory(id: int) -> void:
	if id==1: Profile.inventory.changed.emit()
	else: inventory_snapshot.rpc_id(id,inventories[id].snapshot())
@rpc("authority","call_remote","reliable")
func inventory_snapshot(data: Dictionary) -> void:
	if active: Profile.inventory.restore(data)
@rpc("authority","call_remote","reliable")
func play_action(id: int) -> void:
	if actors.has(id): actors[id].visual.trigger_action()
func pickup_request() -> void:
	if multiplayer.is_server(): pickup(1)
	else: pickup_rpc.rpc_id(1)
@rpc("any_peer","call_remote","reliable")
func pickup_rpc() -> void:
	if multiplayer.is_server(): pickup(multiplayer.get_remote_sender_id())
func pickup(id: int) -> void:
	if not actors.has(id): return
	for key in drops.keys():
		if actors[id].position.distance_to(drops[key].position)>3: continue
		var item: Dictionary=drops[key].item
		var remaining: int=inventories[id].add(item.id,item.quantity)
		if remaining==0: drops.erase(key)
		else: drops[key].item.quantity=remaining
		for recipient in connected_ids(): drop_snapshot.rpc_id(recipient,drops)
		render_drops()
		sync_inventory(id)
		return
@rpc("authority","call_remote","reliable")
func drop_snapshot(data: Dictionary) -> void:
	drops=data
	render_drops()
func render_drops() -> void:
	for key in drop_nodes:
		if is_instance_valid(drop_nodes[key]): drop_nodes[key].queue_free()
	drop_nodes.clear()
	for key in drops: drop_nodes[key]=app.make_drop(drops[key].item,drops[key].position)

func travel_request(index: int) -> void:
	if multiplayer.is_server(): travel(1,index)
	else: travel_rpc.rpc_id(1,index)
@rpc("any_peer","call_remote","reliable")
func travel_rpc(index: int) -> void:
	if multiplayer.is_server(): travel(multiplayer.get_remote_sender_id(),index)
func travel(id: int,index: int) -> void:
	if not actors.has(id) or index<0 or index>=app.island.regions.size(): return
	var region: Dictionary=app.island.regions[index]
	var p:=Vector3(region.x+6,0,region.z+7)
	p.y=IslandShape.height(p.x,p.z)+1
	app.island.ensure_ground(p)
	actors[id].position=p
	actors[id].velocity=Vector3.ZERO
