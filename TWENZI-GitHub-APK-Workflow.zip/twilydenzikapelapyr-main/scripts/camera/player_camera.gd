extends Node3D
var yaw := 0.0
var pitch := -0.12
var distance := 5.5
var first_person := false
var target: CharacterBody3D
var arm: SpringArm3D
var camera: Camera3D
func _ready() -> void:
	top_level = true
	arm = SpringArm3D.new()
	arm.margin = 0.22
	arm.spring_length = distance
	var sphere := SphereShape3D.new()
	sphere.radius = 0.18
	arm.shape = sphere
	add_child(arm)
	camera = Camera3D.new()
	camera.fov = 68
	camera.near = 0.08
	camera.far = 2500
	arm.add_child(camera)
	camera.current = not target.remote_controlled
	if target: arm.add_excluded_object(target.get_rid())
func look(delta: Vector2) -> void:
	yaw -= delta.x*0.003*Preferences.sensitivity
	pitch = clampf(pitch-delta.y*0.003*Preferences.sensitivity,-1.15,0.8)
func switch_view() -> void:
	first_person = not first_person
	arm.spring_length = 0.0 if first_person else distance
	target.visual.visible = not first_person
func _process(delta: float) -> void:
	if not target: return
	var desired := target.global_position+Vector3.UP*(1.68 if first_person else 1.5)
	global_position = desired if first_person else global_position.lerp(desired,1.0-exp(-delta*14))
	rotation = Vector3(pitch,yaw,0)
	arm.spring_length = 0.0 if first_person else distance
func _unhandled_input(event: InputEvent) -> void:
	if target and (target.input_locked or target.remote_controlled): return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED: look(event.relative)
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP: distance = maxf(2,distance-0.5)
		if event.button_index == MOUSE_BUTTON_WHEEL_DOWN: distance = minf(9,distance+0.5)
