extends Node
signal changed
var shadows := true
var view_distance := 3
var vegetation := 0.7
var resolution_scale := 1.0
var fps := 60
var texture_quality := 1
var selected_character := "Twily"
var button_scale := 1.0
var hud_opacity := 1.0
var sensitivity := 1.0
var joystick_radius := 65.0
var joystick_x := 125.0
var joystick_bottom := 140.0
var action_x := 0.0
var action_y := 0.0
var run_hold := false
var action_offset: Vector2:
	get: return Vector2(action_x,action_y)

func _ready() -> void:
	var file := ConfigFile.new()
	if file.load("user://settings.cfg") == OK:
		for key in ["shadows", "view_distance", "vegetation", "resolution_scale", "fps", "texture_quality", "selected_character","button_scale","hud_opacity","sensitivity","joystick_radius","joystick_x","joystick_bottom","action_x","action_y","run_hold"]:
			set(key, file.get_value("graphics", key, get(key)))
	apply()

func apply() -> void:
	Engine.max_fps = fps
	get_viewport().scaling_3d_scale = resolution_scale
	var file := ConfigFile.new()
	for key in ["shadows", "view_distance", "vegetation", "resolution_scale", "fps", "texture_quality", "selected_character","button_scale","hud_opacity","sensitivity","joystick_radius","joystick_x","joystick_bottom","action_x","action_y","run_hold"]:
		file.set_value("graphics", key, get(key))
	file.save("user://settings.cfg")
	changed.emit()

func reset_controls() -> void:
	button_scale=1.0
	hud_opacity=1.0
	sensitivity=1.0
	joystick_radius=65.0
	joystick_x=125.0
	joystick_bottom=140.0
	action_x=0.0
	action_y=0.0
	run_hold=false
