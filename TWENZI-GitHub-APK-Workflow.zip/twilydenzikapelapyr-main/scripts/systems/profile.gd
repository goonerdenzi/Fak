extends Node
signal outfit_changed(config: Dictionary)
var inventory: InventoryModel
var outfits: Dictionary={}
var saved_outfits: Dictionary={}
var character := "Twily"
var network_session := false
var offline_inventory: Dictionary = {}
var path := "user://profile-v2.json"
func _ready() -> void:
	inventory=InventoryModel.new()
	inventory.seed_starter()
	outfits={"Twily":ClothingCatalog.defaults("Twily"),"Denzi":ClothingCatalog.defaults("Denzi")}
	if not OS.get_environment("TWENZI_PROFILE").is_empty(): path=OS.get_environment("TWENZI_PROFILE")
	load_profile()
	inventory.changed.connect(save_profile)
func outfit() -> Dictionary: return outfits[character].duplicate(true)
func equip(slot: String,id: String) -> bool:
	var config:=outfit()
	config[slot]=id
	if not ClothingCatalog.valid(config): return false
	outfits[character]=config
	outfit_changed.emit(config)
	save_profile()
	return true
func save_outfit(title: String) -> bool:
	title=title.strip_edges().left(32)
	if title.is_empty(): return false
	saved_outfits[character+":"+title]=outfit()
	save_profile()
	return true
func load_outfit(title: String) -> bool:
	var key:=character+":"+title
	if not saved_outfits.has(key) or not ClothingCatalog.valid(saved_outfits[key]): return false
	outfits[character]=saved_outfits[key].duplicate(true)
	outfit_changed.emit(outfit())
	save_profile()
	return true
func save_profile() -> bool:
	var file:=FileAccess.open(path+".tmp",FileAccess.WRITE)
	if file==null: return false
	file.store_string(JSON.stringify({"version":2,"inventory":offline_inventory if network_session else inventory.snapshot(),"outfits":outfits,"saved_outfits":saved_outfits}))
	file.close()
	return DirAccess.rename_absolute(path+".tmp",path)==OK
func load_profile() -> bool:
	if not FileAccess.file_exists(path): return false
	var data=JSON.parse_string(FileAccess.get_file_as_string(path))
	if not data is Dictionary or data.get("version")!=2: return false
	if not data.get("outfits") is Dictionary: return false
	for name_value in ["Twily","Denzi"]:
		if not data.outfits.get(name_value) is Dictionary or not ClothingCatalog.valid(data.outfits[name_value]): return false
	if not data.get("saved_outfits",{}) is Dictionary: return false
	for entry in data.get("saved_outfits",{}).values():
		if not entry is Dictionary or not ClothingCatalog.valid(entry): return false
	if not data.get("inventory") is Dictionary or not inventory.restore(data.inventory): return false
	outfits=data.outfits.duplicate(true)
	saved_outfits=data.get("saved_outfits",{}).duplicate(true)
	return true
