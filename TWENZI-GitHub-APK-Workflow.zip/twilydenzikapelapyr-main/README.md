# twilydenzikapelapyr

## Current release: Part 2 cooperative prototype

The existing project now includes a larger connected island with 14 destinations, articulated modular characters, saved outfits, a 24-slot inventory, six-slot hotbar, customized mobile controls, and direct-connect private ENet sessions for a host plus three guests.

**The reference-quality character/environment art is not finished.** The current 3D assets are original placeholders. Android export remains blocked by missing SDK tools/templates; no APK is included.

Open `project.godot` in Godot 4.6.3 and press F5. Use Explore for solo play or Private expedition to host/join using a reachable IP address, UDP port and room code. Desktop additions: **I** inventory, **O** wardrobe, **F** use selected item, **1–6** hotbar.

[Part 2 report and architecture](documentation/part2/README.md) · [Tests](documentation/part2/TESTING.md) · [Screenshots](documentation/part2/screenshots/)

The Part 1 notes below are retained as historical release documentation; the Part 2 report describes current behavior.

---

# TWENZI — Our Little World

Part 1 playable Godot 4 island foundation. This is an early environment and gameplay prototype, **not a finished commercial-quality art build**.

## Run

Open `project.godot` in **Godot 4.6.3** and press F6 on `scenes/main/main.tscn`, or F5 to run the project. No plugins or external asset downloads are required.

```sh
godot --path .
```

Choose **Explore / Free Mode** to enter the island. Settings selects Twily or Denzi for the next expedition. Story Mode is marked Coming Soon.

## Controls

| Action | Desktop | Touch |
| --- | --- | --- |
| Move | WASD | Left floating joystick |
| Look | Captured mouse | Drag right upper area |
| Run | Hold Shift | Toggle Run |
| Jump | Space | Jump; supports second finger while moving |
| Interact / discover | E | Interact near a landmark |
| First / third person | V | View |
| Camera distance | Mouse wheel | Default 5.5 m |
| Pause / resume | Escape | Pause / Resume |
| Region guide | M | Map |

The field guide includes prototype travel points to all ten regions. Each region can be explored on foot. Interacting near markers records discoveries for the current application session. This is not yet a saved survival progression system.

## Included

- Deterministic island roughly 1.7–2 km across, with coastline, mountains, river valley and lake.
- 96 m terrain chunks, nearest-first collision streaming, coarse distant terrain and MultiMesh vegetation.
- Ten region entries, camps, ruin foundations, rock shelter, cascade blockout and a reserved village clearing.
- Separate Twily and Denzi scenes using a shared configurable CharacterBody3D controller.
- Procedural placeholder locomotion and a named skeleton replacement seam.
- Camera-relative movement, gravity, ground collision, jump/landing, spring-arm camera collision, first-person mode.
- Main menu, HUD, pause, settings and field guide.
- Persistent graphics preferences: shadows, view distance, vegetation, procedural material detail, render scale and FPS cap.
- Android ARM64 export preset; SDK and export templates must be installed before building.

## Validation and status

See [testing report](documentation/TESTING.md), [architecture](documentation/ARCHITECTURE.md), [known limitations](documentation/LIMITATIONS.md), [Android build instructions](documentation/ANDROID.md), and [rendered screenshots](documentation/screenshots/).

```sh
godot --headless --path . --editor --import --quit
godot --headless --path . --script tests/integration.gd
# Requires an actual graphics display (not --headless):
TWENZI_CAPTURES=/absolute/output/path godot --path . --script tests/capture.gd
```

The checked-in art is original procedural geometry/materials. No third-party game models, textures or audio have been copied. See [asset provenance](documentation/ASSETS.md).
