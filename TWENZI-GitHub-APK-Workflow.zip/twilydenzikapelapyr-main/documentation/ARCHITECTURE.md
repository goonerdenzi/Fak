# Part 1 architecture

## Entrypoints

`project.godot` runs `scenes/main/main.tscn`. `scripts/ui/main.gd` owns menu/session lifecycle and composes the world, selected character and HUD. It remains active while the world and character are paused. `Preferences` persists graphics and next-session character selection under `user://settings.cfg`.

## World

`scenes/world/island.tscn` uses `scripts/world/island.gd`. Terrain sampling is centralized in `IslandShape`: fixed noise seed, coastline mask, mountains, river channel and lake bank. One unit is one metre. The coastline varies around an approximately 855 m radius. There is no baked terrain download.

Nearby terrain uses 96 m tiles sampled at 6 m intervals, with static triangle collision. Tiles are generated nearest-first, one per process frame; a 3×3 collision neighborhood is generated synchronously before spawning/travel. View settings retain a square radius of 2, 3 or 4 tiles plus one unload margin. Distant tiles sample the same function every 24 m and have no collision or shadows. A detailed tile replaces its corresponding distant tile. Foliage uses MultiMesh instances and a 290 m visibility cutoff. This is a simple terrain LOD system; foliage has distance culling, not mesh/impostor LOD yet.

`data/regions.json` supplies region names, positions, landmark type and discovery text. Add regions there and expand terrain sampling independently. The world is deterministic and the player consumes motion commands, supporting future authoritative multiplayer work. No networking or replication is implemented.

Region landmarks are lightweight runtime geometry. The cave is a walk-in rock shelter, not an excavated heightmap tunnel. The cascade is a blockout requiring further integration into the river. Resource and wildlife regions are reserved environments, not spawning systems.

## Characters and camera

Twily and Denzi share `player.gd` but have separate scenes and appearance exports. Inputs become a small `move/run/jump` command passed to `apply_command`. A future ownership layer can replace local input collection while retaining movement resolution.

`character_visual.gd` supplies placeholders, procedural limb blending and a named Skeleton3D. The placeholder meshes are not skinned to that skeleton. Production replacement requires importing a skinned model, adding AnimationPlayer/AnimationTree clips and mapping movement states. Idle/walk/run/jump/fall and landing state are present; authored turn, landing, interaction and swimming animations are not.

`player_camera.gd` is a smoothed top-level rig. A sphere-shaped SpringArm3D avoids walls, excluding the player body. First person changes the arm length and visual visibility without changing player motion.

## Input and UI

Touch input tracks joystick and look finger IDs independently. Action buttons receive their own touch hit tests so a second finger can trigger jump while the first holds movement. Desktop uses Godot InputMap actions. Pause clears joystick ownership to prevent stuck movement.

The UI uses a 1440×900 reference canvas and anchored controls. Landscape is requested for Android. Android safe-area insets, physical device touch behavior and accessibility sizing still need device verification.

## Quality controls

Compatibility/OpenGL rendering provides a broad GLES3 baseline. Shadows, chunk radius, vegetation count, procedural normal detail, 3D resolution scale and FPS limit are configurable. Render scale is manual; there is no automatic GPU timing controller or Android thermal API integration. Material detail currently controls procedural detail, not texture mip resolution, because the build has no external texture maps.
