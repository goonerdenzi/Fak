# Android build status

Export was actually attempted with Godot 4.6.3 using the checked-in **Android Debug** ARM64 preset. It failed before creating an APK. There is no APK size to report.

Environment inspection found:

- Godot 4.6.3 stable: `/usr/local/bin/godot`.
- OpenJDK 21: `/usr/bin/java`.
- No configured Android SDK, platform-tools/adb, build-tools/apksigner.
- No matching `4.6.3.stable/android_debug.apk` or `android_release.apk` Godot export templates.
- No configured Godot `export/android/java_sdk_path`.

To build on an Android-capable machine:

1. Install the Android export templates for **exactly Godot 4.6.3**.
2. Install the Android SDK command-line tools, platform-tools, and the platform/build-tools versions required by Godot 4.6.3. Accept SDK licenses locally.
3. Set Godot Editor Settings → Export → Android → Java SDK Path and Android SDK Path.
4. Configure/create a debug signing keystore through Godot's Android export setup; never commit release keystores or credentials.
5. Create an output directory and run:

```sh
mkdir -p builds
godot --headless --path . --export-debug 'Android Debug' builds/twenzi-debug.apk
```

The preset identifies the app as `world.twenzi.ourlittleworld`, requests landscape immersive display, exports ARM64, and does not request internet access. Multiplayer comes later.

The initial repository `.gitignore` ignores `export_presets.cfg`, so this public, credential-free preset is explicitly tracked with `git add -f export_presets.cfg`. Keep signing secrets out of the preset. Use a local output directory excluded from version control when building.
