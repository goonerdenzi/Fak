# Part 1 validation — 16 November 2026

## Environment and result

Godot **4.6.3.stable.official.7d41c59c4**, Linux x86_64. Project import completed without script errors. The integration runner completed **45 checks with 0 failures**. See [raw integration output](validation/integration.log).

The game also ran with a real OpenGL renderer on an Xorg dummy display using Mesa llvmpipe (software rendering). Actual viewport images were captured and visually inspected. This is not Android device testing, a hardware GPU benchmark or a claim of target-device FPS. The render log reports unsupported VSync control on this display; it does not indicate a game script failure.

## What was exercised

| Area | Evidence / scope |
| --- | --- |
| Project and main menu | Headless editor import; main scene instantiation; rendered menu |
| Play | Actual Explore button signal loads island and character |
| World | Streaming neighborhood exists; player settles on collider at all ten region entry points |
| Movement | Forward movement on island; backward/left/right movement on an isolated flat collider to distinguish control behavior from steep-slope blocking |
| Running | Actual HUD toggle changes command and increases speed |
| Jump and collision | Rising jump, falling, landing and grounded state on island terrain |
| Camera | Rotation, both modes, body visibility, unchanged player position; spring arm retracts against an inserted solid wall |
| Touch | Synthetic ScreenTouch/ScreenDrag through production input handler: joystick movement, release, right-side look, second-finger jump while joystick is held |
| HUD | All six action buttons inside canvas; containment checks at 1600×900 and 2000×900 landscape viewport sizes |
| Pause | Physics position unchanged while paused; resume restores simulation |
| Interaction | Nearby camp discovery updates session discovery dictionary |
| Field guide | Opens, pauses, travels to selected region and resumes |
| Settings | Settings panel opens; production preference persistence implemented but not covered by a separate restart/persistence test |
| Session lifecycle | Return to menu removes active session; Denzi scene starts successfully |

The automated suite is `tests/integration.gd`; it exits nonzero on assertion failures. It does not simulate a human playthrough of every square metre or validate phone OS input dispatch. Physical multitouch and real-device UI safe areas remain untested.

## Visual inspection

[Five screenshots](screenshots/README.md) show the menu, coast in third person, mountain overlook, lake bank in first person and pause menu. Captures come directly from `ViewportTexture.get_image()` and are not concept art or edited mockups.

Visual inspection found and corrected off-screen HUD anchors, an excessively steep lake entry bank, vegetation spawning in the lake, and water extending with a visibly exposed lake edge. The remaining art limitations are recorded in [LIMITATIONS.md](LIMITATIONS.md): the commercial-quality realistic graphics target has **not** been met.

## Android

The actual debug export attempt failed before APK generation because Android SDK tools and matching export templates are absent. [Export log](validation/android-export.log), [setup requirements](ANDROID.md). OpenJDK 21 is installed; its Godot export setting is not configured. No APK file, APK size or on-device performance result is claimed.

## Reproduce

```sh
godot --headless --path . --editor --import --quit
godot --headless --path . --script tests/integration.gd
TWENZI_CAPTURES=/absolute/capture/path godot --path . --audio-driver Dummy --script tests/capture.gd
```

The capture command requires a graphical display. In this managed workspace, Godot's XDG data/config/cache paths were redirected into `/workspace/work/` because the default home directories are read-only. This is an execution-environment adjustment, not a game requirement.
