# TWENZI Part 2 — implementation and verification

This release extends the existing Godot project and retains Part 1's scenes, controller, camera, input handlers and procedural world. It is a functional cooperative prototype. **The supplied reference images' finished art quality has not been reached.** All four references were inspected before implementation; they informed layout, palettes, clothing direction and environment changes. They were not inserted into the game as backgrounds, sprites or character textures.

## 1. Environment

The original terrain function remains available as `IslandShape.original_height`. An eastern landmass connects to its eastern coast. A 24 m sampling grid measured approximately **4.288 km² of above-sea-level terrain footprint**, versus **2.268 km²** for Part 1: approximately **1.89×** the footprint. East–west sampled extent is approximately **3.264 km**. These figures are estimates from terrain samples, not a hand-surveyed playable-area measurement.

All ten original destinations remain; Eastwind Grove, Saffron Cove, Twin Crown and Lantern Point extend the field guide to fourteen. The beacon is physical 3D geometry. Nearby collision tiles, coarse distant terrain, MultiMesh foliage and distance culling remain in use. Remote players' collision neighborhoods are pinned on the host and periodically pruned after they leave.

Added: sampled-depth turquoise/deep-blue water, animated shallow foam, sky-lit specular reflection, procedural cloud sky, a sunset lighting preset, flowing cascade material, fern-like plants, grass tufts and small flowers. There are two original tree families. Mountain-core occluders use Godot's occlusion system. No planar reflections, volumetric cloud simulation or production waterfall particles are claimed.

## 2. Character models and animations

Twily and Denzi now use `modular_visual.gd`; the original Part 1 visual script is preserved. Twily has a chestnut bob, purple upper layer, shorts, trainers, backpack and hairpin. Denzi has copper hair, a contrasting varsity-style upper layer, wider shoulders and different facial dimensions, cargo-coloured shorts, shoes, backpack and watch.

**These are original articulated placeholder models**, assembled from simple meshes. The 18-bone hierarchy genuinely drives body/clothing attachments. It is a rigid-part rig, not a production skinned/deforming humanoid. Skin weights, sculpted topology, polished hair and textile assets remain asset-production work.

Working procedural poses: idle/breathing, walk, run, jump/fall, landing bend and a brief right-arm interaction/tool action. Turning uses the existing controller's smooth body rotation. Eye blinking is the current limited facial support. Authored animation clips, expressive facial blend shapes, climbing and sitting animations/mechanics are not complete. The shared skeleton and visual action entry point are the replacement/integration seams.

## 3. Modular clothing

`data/clothing.json` defines nineteen options across hair, head, upper, lower, shoes, backpack and accessory slots. The wardrobe has slot tabs, equip/unequip actions, a live rotating 3D preview, named outfit saving and saved-outfit selection. Only a changed slot is rebuilt; other equipment nodes and the body/rig remain intact. Outfit data is stored by character and persists across launches.

All catalog options are available in this prototype closet. There is no unlock/economy system. Clothing geometry fits the placeholder body but is not certified clipping-free across every extreme pose. No external character models are transferred over the network.

## 4. Inventory

`InventoryModel` owns twenty-four slots and data-driven item definitions. Implemented operations: select, move/swap, merge matching stacks, split, drop, pickup, consume, equip tool and equip clothing/equipment. Stack limits, invalid indices, quest-item drop restrictions and save validation are enforced. Category tabs highlight matching categories without rearranging the underlying slots. Capacity and item descriptions/quantities are visible.

The default items cover resources, food, tools, equipment, clothing, accessories, quest items and miscellaneous objects. No combat weapons were added. Berries and water change actual health. Dropped items create labelled 3D pickups. Solo inventory and outfits are saved atomically as `user://profile-v2.json`; invalid saves are rejected rather than applied.

## 5. Hotbar and use

The first six inventory slots form the hotbar. Number keys or touch select a slot. Selection highlights, icons and quantities update from the inventory. Selecting a tool attaches a small original tool mesh to the right hand. Use/F triggers the selected item; food heals, equipment changes appearance, and tools animate and can collect a small resource sample within 5 m of matching instanced vegetation/rocks. This is a gathering demonstration, not the full resource depletion/crafting system.

## 6. Mobile HUD and controls

The HUD has a rendered character portrait, name/camera mode, actual health indicator, explicit level placeholder, heading compass, terrain-derived minimap, world clock, clear-weather label, party count, shortcuts and hotbar. The weather label reflects the sole current weather preset; no dynamic weather system is implemented. Craft opens an explicit future-crafting information panel and inventory link.

Touch finger IDs independently control movement, looking and action buttons. Hold and toggle running are supported. Customization changes joystick size/idle position, action-button scale/offsets, HUD opacity and look sensitivity; reset and saved preferences are available. Desktop movement/camera keys remain and I/O/F/1–6 open inventory/outfit/use/select. Panels fit the tested reference viewport; HUD checks cover 16:9 and 20:9 landscape layouts. Physical Android safe areas and OS multitouch dispatch are not verified.

## 7. Private multiplayer

`Session` uses Godot MultiplayerAPI and ENet. A host plus three guests can share the same island. The host creates an eight-hex-character room secret; guests supply **host IP, UDP port and code**. Default UI port is 24567. This is direct IP/LAN transport. Room codes do not provide discovery, NAT traversal or global internet relay. Different networks may require routing/port forwarding or a future relay. ENet traffic is not encrypted.

The host assigns presence, validates the room/protocol/capacity, and owns remote movement simulation. Clients submit bounded move vectors, run flags, camera yaw and jump requests, never trusted positions. Host snapshots update movement/rotation and remote animations; the local client predicts and reconciles. Stale commands stop after 300 ms. Disconnects remove avatars. Online menus lock only local input; they do not pause the host or other players.

Equipment dictionaries are validated against allowed IDs and slot assignments on the host. Only compact equipment/tool IDs are synchronized. Inventory operations, consumables, shared drops/pickups and field-guide travel are also validated/applied on the host. Guests receive their own inventory snapshots. Each guest starts with a server-issued session inventory; **session inventories are ephemeral**. Solo inventory is restored on leaving, rather than mixing untrusted/session state into solo saves. Named wardrobe configurations remain local profile data.

Peer-to-peer relay notifications are disabled because all game RPCs route through the host. Explicit recipient filtering also prevents broadcasts to closing peers. This was necessary to eliminate an intermittent simultaneous-disconnect ENet send error found during testing.

## 8. Tests and reproduction

See [TESTING.md](TESTING.md) and checked-in logs. The runners require successful exit codes, a final result line, and no `ERROR:` or `SCRIPT ERROR` output. Network testing launches real separate Godot processes, including four successful participants and two additional rejection probes.

```sh
godot --headless --path . --editor --import --quit
python3 tests/run_suite.py --logs /tmp/twenzi-offline-tests
python3 tests/run_network.py --logs /tmp/twenzi-network-tests --port 25677
# A graphical display is required for captures:
TWENZI_CAPTURES=/tmp/twenzi-images godot --path . --audio-driver Dummy --script tests/part2_capture.gd
```

The Python runners isolate user data and preferences in temporary directories. They do not use a player's existing save. The project itself needs no Python to play.

## 9. Performance and Android

Rendering uses Godot Compatibility/OpenGL, configurable shadows/view distance/foliage, near/far terrain detail, instancing, occlusion and distance culling. Render resolution and FPS caps remain configurable. Automatic dynamic resolution, production foliage impostor LOD and thermal APIs are not implemented.

No Redmi Note 13 5G or OPPO F31 Pro+ 5G hardware was available. No mobile FPS, memory, battery or thermal performance is claimed. Screenshots were rendered using Mesa llvmpipe on the Linux environment, which is not a mobile GPU benchmark.

The Android preset now permits internet access for ENet. A fresh export attempt failed: Android SDK platform/build tools and Godot 4.6.3 Android export templates are missing; the Godot Java SDK setting is unconfigured despite installed OpenJDK 21. **No Part 2 APK exists.** See the captured export log and the earlier Android setup instructions.

## 10. Remaining blockers and scope

- The stylized-realistic visual target remains incomplete. Current characters, modular clothes, landmarks and vegetation are prototype assets; they do not match the supplied sheets' production quality.
- No production skinned meshes, polished locomotion/interaction clips, expressive facial rig, sitting or climbing mechanics.
- Sparse/repeated foliage and terrain transitions, approximate water depth/foam, simple cascade geometry and main-thread generation still need an environment/performance pass.
- Multiplayer is a direct-connect foundation, tested on local loopback, not across phones/carriers. No relay, reconnect recovery, host migration, dedicated persistent server or production anti-abuse layer.
- Session inventory is intentionally transient; survival progression, crafting, resource depletion and progression are not implemented.
- Physical Android UI/input and target-device performance/build validation remain blocked by the missing SDK/templates/devices.

## 11. Git

Development continued on `main` in `/workspace/twilydenzikapelapyr`. No repository reset, duplicate project or deletion of Part 1 scripts/scenes/assets was used. The tested source milestone is `86de352`. Source and validation/documentation are committed separately. The final chat reports the verified pushed head.

## 12. Proposed next steps for Part 3 — not implemented

1. Agree on the production character/vegetation asset pipeline and replace the rigid placeholders with licensed or original skinned assets while retaining slot IDs and controller interfaces.
2. Install the matching Android SDK/templates, produce an actual debug APK, and run touch, graphics, memory and thermal tests on both named devices.
3. Choose a relay/NAT traversal design and persistent authoritative session/save policy before claiming internet-wide private rooms.
4. Build the agreed survival/gathering/crafting slice using the existing inventory, hotbar, tool-action and authority seams; define save migration first.
5. Add device/network regression tests and complete animation, terrain-composition and mobile-performance passes before expanding content further.
