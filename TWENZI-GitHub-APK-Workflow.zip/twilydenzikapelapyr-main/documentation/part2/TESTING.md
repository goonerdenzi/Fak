# Part 2 validation

Godot 4.6.3 stable, Linux x86_64. The Part 1 baseline passed its original 45 checks before implementation. Intermediate world, character and UI checks were run during the milestone work; they are not double-counted below.

Final offline suite:

| Runner | Passed | Failed |
| --- | ---: | ---: |
| Inventory, persistence, rig and slot models | 25 | 0 |
| Inventory/outfit/control UI interactions | 18 | 0 |
| Preserved gameplay, HUD layouts and fourteen regions | 59 | 0 |
| **Offline total** | **102** | **0** |

Final network suite uses one real host process and three real joining client processes. It additionally launches a wrong-code probe and an over-capacity probe; these do not count as successfully connected players.

| Process | Passed | Failed |
| --- | ---: | ---: |
| Host | 10 | 0 |
| Client 1 | 13 | 0 |
| Client 2 | 8 | 0 |
| Client 3 | 8 | 0 |
| Wrong-code probe | 1 | 0 |
| Fifth-player probe | 1 | 0 |
| **Network total** | **41** | **0** |

**Combined final assertions: 143 passed, 0 failed.** See `validation/` for raw logs. Runners also fail on engine/script errors, independently of assertion counts. An earlier network run passed its assertions but produced a disconnect-time transport error; that run was rejected, the unused server relay path was disabled, and the suite rerun. A separate client jump-prediction mismatch was corrected by reconciling the accepted server jump velocity; the final run includes that fix.

Coverage includes actual Explore-button startup; controller/collision/jump/landing; first/third-person switching; camera wall avoidance; synthetic multitouch and held-run release; viewport containment; item move/split/use/drop/pickup; real clothing geometry and stable unaffected slot nodes; saved outfit/profile round trips; visible held tools; host creation; four-client presence; authoritative remote running/jumping; host movement received by clients; validated outfit replication; inventory response/UI refresh; shared drop/pickup; authoritative region travel; online menu behavior; capacity/room rejection; and disconnect cleanup.

Network tests run over **127.0.0.1 with real ENet UDP sockets**. They do not establish cross-internet, NAT, carrier, packet-loss, reconnect or physical-phone behavior. Touch events are injected through the production handlers; Android OS touch dispatch is not tested. Category filtering and named outfits are prototype UI flows, not a complete player usability study.

Screenshots are actual Godot viewport images, rendered with Mesa llvmpipe through Xorg. The eastern-beacon capture uses a developer overview camera in the same live island. The images are not concept art and are not inserted into the game.

Performance on the two target phones was not measured. An Android export was attempted but failed before creating an APK; the export failure is recorded separately and is not counted as a passing build.
