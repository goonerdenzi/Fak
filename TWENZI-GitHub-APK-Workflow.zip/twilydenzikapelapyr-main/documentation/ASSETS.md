# Asset provenance

All current geometry and materials were created in this repository specifically for TWENZI:

- Island: deterministic height-function mesh generation in `scripts/world`.
- Palm and broadleaf vegetation: original procedural mesh construction with shader wind.
- Rocks, landmark blockouts, character placeholders: procedural geometry.
- Terrain, foliage and water shaders: project-authored shader code.
- App icon: original SVG.
- UI font: Godot's bundled default font; distributed with the engine under its bundled font license.

No downloaded third-party models, textures, game assets, animations, music or audio are included. This provenance statement does not assign a new license to the repository; ownership and licensing remain the repository owner's decision. Review licenses explicitly when adding external assets later.
