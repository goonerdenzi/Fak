# Known limitations and remaining work

- **Visual target remains incomplete.** Screenshots are actual engine output, but this is a procedural prototype, below the requested premium realistic commercial art standard. Vegetation repetition, sparse understory, simple rock shapes, shoreline triangulation and LOD transitions remain visible. It needs authored terrain composition, high-quality licensed/original foliage, PBR texture sets and art direction passes.
- Characters are capsule-based placeholders with distinguishable clothing/skin palettes. Procedural limb motion is not production animation. The skeleton is a replacement seam, not a fully skinned humanoid rig. Authored landing/turn/interaction/swimming clips and AnimationTree transitions remain outstanding.
- The island has geographical variation and ten discovery destinations, but is not fully populated with villages, wildlife, resource systems, hidden puzzles or survival activities. Ruins/camps are blockouts; the rock shelter is not a subterranean cave network. The waterfall is a simple cascade blockout.
- Ocean water is opaque shader water without refraction, shoreline foam or a full underwater system. Basic ocean buoyancy prevents endless sinking; freshwater swimming is not implemented.
- Terrain and landmark geometry collide. Instanced decorative rocks and vegetation do not have individual colliders yet.
- Nearby terrain is generated on the main thread with a per-frame tile budget. Teleport/preload and density changes can hitch. Threaded generation, foliage LOD, detailed profiling and pooling remain future work. Distant terrain tiles can show seams at transitions to detailed tiles.
- Settings changes rebuild streamed tiles; material quality changes procedural normals, not texture resolution. Automatic dynamic resolution and thermal throttling are not implemented.
- Discovery state lasts only for the running application. No game-save system, inventory, survival, multiplayer or story content has been implemented in Part 1.
- No production soundscape, music or animation assets are included.
- Physical Android touch, notch/safe-area behavior, battery/thermal performance and memory usage are unverified. No FPS claims are made for Redmi Note 13 5G or OPPO F31 Pro+ 5G.
- No APK was generated: Android SDK/build tools and Godot Android export templates are missing from this workspace. Java 21 is installed but the Godot Java SDK setting still requires configuration.
