# Actual Godot viewport captures

These images are rendered by Godot 4.6.3 with the OpenGL Compatibility renderer, using Mesa llvmpipe in the development environment. They show prototype art, not final production quality. No image-generation or image-retouching tools were used.

- [Main menu and island preview](01-menu.png)
- [Driftwood Coast — third person](02-coast.png)
- [Crown Ridge — mountain overlook](03-highlands.png)
- [Mirror Lake — first person](04-lake-first-person.png)
- [Pause menu](05-pause.png)

Regenerate with `tests/capture.gd`. The optional `-- --lake-only` argument refreshes the lake and pause views when iterating on that region.
